export const STORE_INFO = {
  name: 'ALIF SHOP',
  nameBn: 'আলিফ শপ',
  tagline: 'পুরুষদের সেরা পোশাকের বিশ্বস্ত প্রতিষ্ঠান',
  taglineEn: 'Premium Menswear & Street Fashion in Raozan',
  address: 'Gohira, Raozan, Chattogram, Bangladesh',
  addressBn: 'গহিরা, রাউজান, চট্টগ্রাম, বাংলাদেশ',
  landmarkBn: 'গহিরা শান্তির বাজার সংলগ্ন, রাউজান, চট্টগ্রাম',
  phone: '+880 1870-023718',
  phoneDisplay: '01870-023718',
  whatsapp: '8801870023718',
  email: 'alifshop.gohira@gmail.com',
  hoursBn: 'সকাল ৯:০০ টা – রাত ১০:০০ টা (সপ্তাহের ৭ দিনই খোলা)',
  hoursEn: '9:00 AM – 10:00 PM (Open 7 Days)',
  freeDeliveryThreshold: 2000,
  shippingFees: {
    insideChattogram: 60,
    outsideChattogram: 120,
    freeOver: 2000
  }
};

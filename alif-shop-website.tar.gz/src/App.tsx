import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSlider } from './components/HeroSlider';
import { CuratedCategories } from './components/CuratedCategories';
import { ProductGrid } from './components/ProductGrid';
import { ProductDetailModal } from './components/ProductDetailModal';
import { SizeChartModal } from './components/SizeChartModal';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { AboutUsModal } from './components/AboutUsModal';
import { ContactModal } from './components/ContactModal';
import { ReturnPolicyModal } from './components/ReturnPolicyModal';
import { DeliveryPolicyModal } from './components/DeliveryPolicyModal';
import { AboutSection } from './components/AboutSection';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { WishlistModal } from './components/WishlistModal';
import { CustomerReviews } from './components/CustomerReviews';
import { Footer } from './components/Footer';

import { PRODUCTS } from './data/products';
import { STORE_INFO } from './data/storeInfo';
import { Product, CartItem, Currency, Language, ProductCategory, Order } from './types';
import { MessageCircle, ArrowUp, Check } from 'lucide-react';

export default function App() {
  // Global Preferences (Bengali by default as requested)
  const [currency, setCurrency] = useState<Currency>('BDT');
  const [language, setLanguage] = useState<Language>('bn');

  // Navigation & Category Filter
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');

  // Cart State (Persisted in localStorage)
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('alif_shop_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Wishlist State (Persisted in localStorage)
  const [wishlistIds, setWishlistIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('alif_shop_wishlist');
      return saved ? JSON.parse(saved) : ['alif-ts-01', 'alif-kp-01'];
    } catch {
      return ['alif-ts-01', 'alif-kp-01'];
    }
  });

  // Voucher Promo Code (e.g. ALIF10)
  const [appliedPromo, setAppliedPromo] = useState<string>('');

  // Modals
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const [isReturnPolicyOpen, setIsReturnPolicyOpen] = useState(false);
  const [isDeliveryPolicyOpen, setIsDeliveryPolicyOpen] = useState(false);
  const [isSizeChartOpen, setIsSizeChartOpen] = useState(false);
  const [sizeChartGroup, setSizeChartGroup] = useState<'t-shirts-polo' | 'shirts' | 'pants'>('t-shirts-polo');
  const [orderTrackingState, setOrderTrackingState] = useState<{ isOpen: boolean; orderId?: string }>({
    isOpen: false
  });
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  // Floating Toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Scroll to Top
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowScrollTop(window.scrollY > 400);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Sync Cart
  useEffect(() => {
    try {
      localStorage.setItem('alif_shop_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error(e);
    }
  }, [cartItems]);

  // Sync Wishlist
  useEffect(() => {
    try {
      localStorage.setItem('alif_shop_wishlist', JSON.stringify(wishlistIds));
    } catch (e) {
      console.error(e);
    }
  }, [wishlistIds]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 2500);
  };

  // Cart Operations
  const handleAddToCart = (product: Product, size: string, color: string, qty = 1) => {
    const existingIdx = cartItems.findIndex(
      (item) => item.product.id === product.id && item.selectedSize === size && item.selectedColor === color
    );

    if (existingIdx > -1) {
      const updated = [...cartItems];
      updated[existingIdx].quantity += qty;
      setCartItems(updated);
    } else {
      const newItem: CartItem = {
        id: `${product.id}-${size}-${Date.now()}`,
        product,
        selectedSize: size,
        selectedColor: color,
        quantity: qty
      };
      setCartItems((prev) => [...prev, newItem]);
    }

    showToast(language === 'bn' ? `"${product.titleBn}" ব্যাগে যোগ হয়েছে!` : `Added "${product.title}" to your bag!`);
  };

  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCartItems((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[]
    );
  };

  const handleRemoveCartItem = (id: string) => {
    setCartItems((prev) => prev.filter((item) => item.id !== id));
  };

  // Wishlist Operations
  const handleToggleWishlist = (product: Product) => {
    if (wishlistIds.includes(product.id)) {
      setWishlistIds((prev) => prev.filter((id) => id !== product.id));
      showToast(language === 'bn' ? 'উইশলিস্ট থেকে সরানো হয়েছে' : 'Removed from wishlist');
    } else {
      setWishlistIds((prev) => [...prev, product.id]);
      showToast(language === 'bn' ? 'উইশলিস্টে যুক্ত করা হয়েছে' : 'Saved to your wishlist');
    }
  };

  const handleBuyNow = (product: Product, size: string, color: string, qty = 1) => {
    handleAddToCart(product, size, color, qty);
    setSelectedProduct(null);
    setIsCheckoutOpen(true);
  };

  const cartSubtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const discountAmount = appliedPromo ? Math.round(cartSubtotal * 0.1) : 0;
  const cartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  const wishlistProducts = PRODUCTS.filter((p) => wishlistIds.includes(p.id));

  const handleOrderSuccess = (order: Order) => {
    setCartItems([]);
    setAppliedPromo('');
  };

  const handleSelectCategory = (cat?: ProductCategory) => {
    setActiveCategory(cat || 'all');
    const el = document.getElementById('catalog-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F5] text-stone-900 selection:bg-amber-600 selection:text-white relative">
      
      {/* Toast Alert */}
      {toastMessage && (
        <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-50 bg-stone-900 text-white px-5 py-3 rounded-full shadow-2xl flex items-center space-x-2 text-xs font-semibold animate-scaleIn border border-stone-700">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Navbar */}
      <Navbar
        cartCount={cartCount}
        cartTotal={Math.max(0, cartSubtotal - discountAmount)}
        wishlistCount={wishlistIds.length}
        currency={currency}
        setCurrency={setCurrency}
        language={language}
        setLanguage={setLanguage}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenAbout={() => setIsAboutModalOpen(true)}
        onOpenContact={() => setIsContactModalOpen(true)}
        onOpenReturnPolicy={() => setIsReturnPolicyOpen(true)}
        onOpenDeliveryPolicy={() => setIsDeliveryPolicyOpen(true)}
        onOpenOrderTracking={() => setOrderTrackingState({ isOpen: true })}
        activeCategory={activeCategory}
        setActiveCategory={setActiveCategory}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
      />

      {/* Main Page Sections */}
      <main className="flex-1">
        {/* Hero Banner Slider with New Collections & Bestsellers */}
        <HeroSlider
          language={language}
          onExplore={handleSelectCategory}
          onOpenContact={() => setIsContactModalOpen(true)}
        />

        {/* Curated Categories */}
        <CuratedCategories
          language={language}
          onSelectCategory={handleSelectCategory}
        />

        {/* Product Catalog */}
        <ProductGrid
          products={PRODUCTS}
          currency={currency}
          language={language}
          wishlistIds={wishlistIds}
          onToggleWishlist={handleToggleWishlist}
          onQuickView={(p) => setSelectedProduct(p)}
          onAddToCart={(p, size, color) => handleAddToCart(p, size, color, 1)}
          activeCategory={activeCategory}
          setActiveCategory={setActiveCategory}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />

        {/* About ALIF SHOP Section (Gohira, Raozan, Chattogram) */}
        <AboutSection
          language={language}
          onOpenContact={() => setIsContactModalOpen(true)}
          onOpenReturnPolicy={() => setIsReturnPolicyOpen(true)}
        />

        {/* Customer Reviews & Feedback */}
        <CustomerReviews language={language} />
      </main>

      {/* Footer */}
      <Footer
        language={language}
        onOpenAbout={() => setIsAboutModalOpen(true)}
        onOpenContact={() => setIsContactModalOpen(true)}
        onOpenReturnPolicy={() => setIsReturnPolicyOpen(true)}
        onOpenDeliveryPolicy={() => setIsDeliveryPolicyOpen(true)}
        onOpenOrderTracking={() => setOrderTrackingState({ isOpen: true })}
        onOpenSizeChart={() => {
          setSizeChartGroup('t-shirts-polo');
          setIsSizeChartOpen(true);
        }}
        onNavigateCategory={handleSelectCategory}
      />

      {/* Floating Action Buttons: WhatsApp & Scroll to top */}
      <div className="fixed bottom-6 right-6 z-30 flex flex-col space-y-3">
        {showScrollTop && (
          <button
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="w-11 h-11 rounded-full bg-white text-stone-800 shadow-xl border border-stone-200 hover:bg-stone-50 flex items-center justify-center transition-all animate-fadeIn"
            aria-label="Scroll to top"
          >
            <ArrowUp className="w-5 h-5" />
          </button>
        )}

        {/* Direct WhatsApp Concierge to Raozan Outlet */}
        <a
          href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20ALIF%20SHOP%20(Gohira,%20Raozan),%20I%20would%20like%20to%20order.`}
          target="_blank"
          rel="noopener noreferrer"
          className="w-13 h-13 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white shadow-xl flex items-center justify-center transition-transform hover:scale-110 group relative"
          aria-label="WhatsApp"
          title="Chat on WhatsApp"
        >
          <MessageCircle className="w-6 h-6" />
          <span className="absolute right-full mr-3 bg-stone-900 text-white text-[11px] font-semibold px-2.5 py-1 rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-md pointer-events-none">
            {language === 'bn' ? 'হোয়াটসঅ্যাপে সরাসরি অর্ডার করুন' : 'Chat on WhatsApp'}
          </span>
        </a>
      </div>

      {/* Slide-over Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cartItems={cartItems}
        currency={currency}
        language={language}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        appliedPromo={appliedPromo}
        setAppliedPromo={setAppliedPromo}
        discountAmount={discountAmount}
      />

      {/* Wishlist Modal */}
      <WishlistModal
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlistProducts={wishlistProducts}
        currency={currency}
        language={language}
        onRemoveFromWishlist={handleToggleWishlist}
        onAddToCart={(p, sz, col) => handleAddToCart(p, sz, col, 1)}
        onQuickView={(p) => {
          setIsWishlistOpen(false);
          setSelectedProduct(p);
        }}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={Boolean(selectedProduct)}
        onClose={() => setSelectedProduct(null)}
        currency={currency}
        language={language}
        isWishlisted={selectedProduct ? wishlistIds.includes(selectedProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
        onOpenSizeChart={(group) => {
          if (group) setSizeChartGroup(group);
          setIsSizeChartOpen(true);
        }}
      />

      {/* Size Chart Modal */}
      <SizeChartModal
        isOpen={isSizeChartOpen}
        onClose={() => setIsSizeChartOpen(false)}
        language={language}
        initialTab={sizeChartGroup}
      />

      {/* About Us Modal */}
      <AboutUsModal
        isOpen={isAboutModalOpen}
        onClose={() => setIsAboutModalOpen(false)}
        language={language}
      />

      {/* Contact & Hotline Modal */}
      <ContactModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        language={language}
      />

      {/* Return & Exchange Policy Modal */}
      <ReturnPolicyModal
        isOpen={isReturnPolicyOpen}
        onClose={() => setIsReturnPolicyOpen(false)}
        language={language}
      />

      {/* Delivery Policy Modal */}
      <DeliveryPolicyModal
        isOpen={isDeliveryPolicyOpen}
        onClose={() => setIsDeliveryPolicyOpen(false)}
        language={language}
      />

      {/* Order Tracking Modal */}
      <OrderTrackingModal
        isOpen={orderTrackingState.isOpen}
        onClose={() => setOrderTrackingState({ isOpen: false })}
        language={language}
        presetOrderId={orderTrackingState.orderId}
      />

      {/* Checkout Modal */}
      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        cartItems={cartItems}
        currency={currency}
        language={language}
        discountAmount={discountAmount}
        appliedPromo={appliedPromo}
        onOrderSuccess={handleOrderSuccess}
        onOpenOrderTracking={(id) => setOrderTrackingState({ isOpen: true, orderId: id })}
      />

    </div>
  );
}

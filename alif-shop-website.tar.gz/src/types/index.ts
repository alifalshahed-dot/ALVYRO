export type ProductCategory =
  | 'all'
  | 't-shirt'
  | 'polo-shirt'
  | 'casual-shirt'
  | 'formal-shirt'
  | 'formal-pant'
  | 'korean-pant'
  | 'casual-trouser';

export interface Product {
  id: string;
  sku: string;
  title: string;
  titleBn: string;
  category: ProductCategory;
  categoryGroup: 't-shirts-polo' | 'shirts' | 'pants';
  categoryName: string;
  categoryNameBn: string;
  price: number; // in BDT
  originalPrice?: number;
  discountPercent?: number;
  inStock: boolean;
  featured?: boolean;
  isNewArrival?: boolean;
  isBestseller?: boolean;
  fabric: string;
  fabricBn: string;
  gsm?: string;
  color: string;
  colorCode: string;
  sizes: string[];
  image: string;
  additionalImages: string[];
  description: string;
  descriptionBn: string;
  details: {
    fit: string;
    material: string;
    features: string;
    care: string;
  };
  rating: number;
  reviewCount: number;
}

export interface CartItem {
  id: string;
  product: Product;
  selectedSize: string;
  selectedColor: string;
  quantity: number;
}

export interface Order {
  id: string;
  customerName: string;
  phone: string;
  email: string;
  address: string;
  district: string;
  items: CartItem[];
  subtotal: number;
  shippingFee: number;
  discount: number;
  total: number;
  paymentMethod: 'cod' | 'bkash' | 'nagad' | 'card';
  status: 'confirmed' | 'processing' | 'shipped' | 'delivered';
  createdAt: string;
  trackingCode: string;
}

export type Currency = 'BDT' | 'USD';
export type Language = 'bn' | 'en';

import React from 'react';
import { X, Truck, CheckCircle, MapPin, ShieldCheck, Clock } from 'lucide-react';
import { STORE_INFO } from '../data/storeInfo';
import { Language } from '../types';

interface DeliveryPolicyModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const DeliveryPolicyModal: React.FC<DeliveryPolicyModalProps> = ({ isOpen, onClose, language }) => {
  if (!isOpen) return null;
  const isBn = language === 'bn';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 bg-stone-900 text-white flex items-center justify-between border-b border-stone-800">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-amber-600 flex items-center justify-center text-white">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-serif font-bold tracking-wide">
                {isBn ? 'ডেলিভারি পলিসি ও চার্জ' : 'Delivery Policy & Shipping'}
              </h3>
              <p className="text-xs text-stone-300">
                {isBn ? 'সারা দেশে বিশ্বস্ত ক্যাশ অন ডেলিভারি • আলিফ শপ' : 'Cash on Delivery Across Bangladesh • ALIF SHOP'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-stone-300 hover:text-white hover:bg-stone-800 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6 text-xs text-stone-700 leading-relaxed">
          {/* Free Shipping Alert */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-950 flex items-center space-x-3">
            <ShieldCheck className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <h4 className="font-bold text-sm">
                {isBn ? '🎉 ২,০০০ টাকার বেশি অর্ডারে সম্পূর্ণ ফ্রি ডেলিভারি!' : 'FREE Delivery on Orders Above ৳2,000!'}
              </h4>
              <p className="text-[11px] text-emerald-800 mt-0.5">
                {isBn ? 'রাউজান, চট্টগ্রাম কিংবা দেশের যেকোনো প্রান্তে ডেলিভারি চার্জ সম্পূর্ণ ফ্রি।' : 'Valid for all districts across Bangladesh.'}
              </p>
            </div>
          </div>

          {/* Pricing table */}
          <div>
            <h4 className="font-serif font-bold text-stone-900 text-sm mb-3">
              {isBn ? 'ডেলিভারি এলাকা ও সময়সীমা:' : 'Delivery Areas & Rates:'}
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-900 text-xs">রাউজান ও চট্টগ্রাম জেলা</span>
                  <span className="font-mono font-bold text-amber-700 text-sm">৳৬০</span>
                </div>
                <div className="flex items-center space-x-1.5 text-stone-600">
                  <Clock className="w-3.5 h-3.5 text-stone-400" />
                  <span>২৪ থেকে ৪৮ ঘণ্টার মধ্যে ডেলিভারি</span>
                </div>
                <p className="text-[11px] text-stone-500">
                  গহিরা, রাউজান সদর, পাহাড়তলী, নোয়াপাড়া ও চট্টগ্রাম মেট্রো সিটিতে হোম ডেলিভারি।
                </p>
              </div>

              <div className="p-4 rounded-2xl border border-stone-200 bg-stone-50 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-stone-900 text-xs">চট্টগ্রামের বাইরে (সারা দেশ)</span>
                  <span className="font-mono font-bold text-amber-700 text-sm">৳১২০</span>
                </div>
                <div className="flex items-center space-x-1.5 text-stone-600">
                  <Clock className="w-3.5 h-3.5 text-stone-400" />
                  <span>২ থেকে ৩ কার্যদিবস</span>
                </div>
                <p className="text-[11px] text-stone-500">
                  ঢাকা, সিলেট, রাজশাহী, খুলনা সহ দেশের ৬৪ জেলার সকল থানা ও সদরে ডোরস্টেপ হোম ডেলিভারি।
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-2 pt-2">
            <h4 className="font-bold text-stone-900 text-xs">
              {isBn ? '📦 ডেলিভারি প্রক্রিয়া ও কুরিয়ার পার্টনার:' : 'Courier Partners & Verification:'}
            </h4>
            <p>
              আমরা <strong>Steadfast Courier</strong>, <strong>RedX Express</strong> এবং <strong>Sundarban Courier</strong>-এর মাধ্যমে দ্রুত পার্সেল পাঠাই। পার্সেল ডেলিভারিম্যান আসার আগে আপনাকে ফোন করবে এবং পণ্য হাতে পেয়ে মূল্য পরিশোধ (Cash on Delivery) করতে পারবেন।
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-stone-50 border-t border-stone-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold uppercase tracking-wider"
          >
            {isBn ? 'ঠিক আছে' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};

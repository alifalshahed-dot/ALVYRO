import React, { useState } from 'react';
import { Heart, Eye, ShoppingBag, Sparkles, Check } from 'lucide-react';
import { Product, Currency, Language } from '../types';
import { formatPrice } from '../utils/currency';

interface ProductCardProps {
  product: Product;
  currency: Currency;
  language: Language;
  isWishlisted: boolean;
  onToggleWishlist: (p: Product) => void;
  onQuickView: (p: Product) => void;
  onAddToCart: (p: Product, size: string, color: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  currency,
  language,
  isWishlisted,
  onToggleWishlist,
  onQuickView,
  onAddToCart
}) => {
  const [isHovered, setIsHovered] = useState(false);
  const [quickSizeSelect, setQuickSizeSelect] = useState(false);
  const [addedAnimation, setAddedAnimation] = useState(false);

  const isBn = language === 'bn';

  const handleQuickAdd = (size: string) => {
    onAddToCart(product, size, product.color);
    setQuickSizeSelect(false);
    setAddedAnimation(true);
    setTimeout(() => setAddedAnimation(false), 1800);
  };

  return (
    <div 
      className="group relative flex flex-col bg-white rounded-2xl overflow-hidden border border-stone-200 hover:border-stone-300 hover:shadow-xl transition-all duration-300"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => {
        setIsHovered(false);
        setQuickSizeSelect(false);
      }}
    >
      {/* Image Container */}
      <div className="relative aspect-[3/4] w-full overflow-hidden bg-stone-100 cursor-pointer" onClick={() => onQuickView(product)}>
        <img
          src={isHovered && product.additionalImages.length > 1 ? product.additionalImages[1] : product.image}
          alt={product.title}
          className="h-full w-full object-cover object-center group-hover:scale-105 transition-all duration-700 ease-out"
          loading="lazy"
        />

        {/* Badges */}
        <div className="absolute top-3 left-3 flex flex-col gap-1.5 z-10">
          {product.isBestseller && (
            <span className="bg-amber-600 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full shadow-sm flex items-center space-x-1">
              <Sparkles className="w-2.5 h-2.5 text-amber-200" />
              <span>Bestseller</span>
            </span>
          )}
          {product.isNewArrival && !product.isBestseller && (
            <span className="bg-stone-900 text-white text-[10px] font-bold uppercase tracking-wider px-2.5 py-1 rounded-full shadow-sm">
              New Arrival
            </span>
          )}
          {product.discountPercent && (
            <span className="bg-amber-500 text-stone-900 text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full shadow-sm">
              -{product.discountPercent}% OFF
            </span>
          )}
        </div>

        {/* Wishlist Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-3 right-3 p-2 rounded-full backdrop-blur-md transition-all z-10 ${
            isWishlisted
              ? 'bg-amber-600 text-white shadow-md'
              : 'bg-white/80 text-stone-700 hover:bg-white hover:text-amber-600'
          }`}
          aria-label="Wishlist toggle"
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-current' : ''}`} />
        </button>

        {/* Quick View Button on Hover */}
        <div className="absolute inset-x-3 bottom-3 z-10 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
          {!quickSizeSelect ? (
            <div className="flex gap-2">
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onQuickView(product);
                }}
                className="flex-1 py-2.5 bg-white/95 hover:bg-white text-stone-900 rounded-xl text-xs font-semibold tracking-wider uppercase transition-all shadow-md flex items-center justify-center space-x-1.5 backdrop-blur-sm"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>{isBn ? 'বিস্তারিত' : 'Quick View'}</span>
              </button>

              <button
                onClick={(e) => {
                  e.stopPropagation();
                  if (product.sizes.length === 1) {
                    handleQuickAdd(product.sizes[0]);
                  } else {
                    setQuickSizeSelect(true);
                  }
                }}
                className={`px-3.5 py-2.5 rounded-xl text-xs font-semibold uppercase transition-all shadow-md flex items-center justify-center space-x-1 ${
                  addedAnimation 
                    ? 'bg-emerald-700 text-white' 
                    : 'bg-amber-600 hover:bg-[#601927] text-white'
                }`}
              >
                {addedAnimation ? (
                  <Check className="w-4 h-4 animate-scaleIn" />
                ) : (
                  <>
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span className="hidden sm:inline">{isBn ? 'ব্যাগে নিন' : 'Add'}</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            /* Quick Size Selector Panel */
            <div 
              className="bg-stone-900/95 backdrop-blur-md p-3 rounded-xl shadow-xl text-white animate-fadeIn"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-[10px] uppercase font-bold tracking-wider text-amber-300 mb-1.5 text-center">
                {isBn ? 'সাইজ নির্বাচন করুন' : 'Select Your Size'}
              </div>
              <div className="flex flex-wrap gap-1.5 justify-center">
                {product.sizes.map((sz) => (
                  <button
                    key={sz}
                    onClick={() => handleQuickAdd(sz)}
                    className="px-2.5 py-1 bg-white/10 hover:bg-amber-600 text-white text-xs font-semibold rounded-lg border border-white/20 transition-all hover:border-amber-600"
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Product Information */}
      <div className="p-4 flex flex-col flex-1 justify-between">
        <div>
          <div className="flex items-center justify-between text-[11px] text-stone-500 mb-1">
            <span className="uppercase tracking-widest font-semibold text-amber-600">
              {isBn ? product.categoryNameBn : product.categoryName}
            </span>
            <span className="font-mono text-stone-400">{product.sku}</span>
          </div>

          <h3 
            onClick={() => onQuickView(product)}
            className="text-sm sm:text-base font-serif font-bold text-stone-900 hover:text-amber-600 transition-colors cursor-pointer line-clamp-1"
            title={product.title}
          >
            {isBn ? product.titleBn : product.title}
          </h3>

          <p className="text-xs text-stone-500 line-clamp-1 mt-1 font-light">
            {isBn ? product.fabricBn : product.fabric}
          </p>
        </div>

        <div className="mt-3 pt-3 border-t border-stone-100 flex items-center justify-between">
          {/* Price */}
          <div className="flex items-baseline space-x-2">
            <span className="text-base sm:text-lg font-bold font-mono text-stone-900">
              {formatPrice(product.price, currency)}
            </span>
            {product.originalPrice && (
              <span className="text-xs text-stone-400 line-through font-mono">
                {formatPrice(product.originalPrice, currency)}
              </span>
            )}
          </div>

          {/* Color swatch pill */}
          <div className="flex items-center space-x-1" title={product.color}>
            <span 
              className="w-3.5 h-3.5 rounded-full border border-stone-300 shadow-inner" 
              style={{ backgroundColor: product.colorCode }} 
            />
            <span className="text-[10px] text-stone-500 truncate max-w-[65px]">
              {product.color.split(' ')[0]}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

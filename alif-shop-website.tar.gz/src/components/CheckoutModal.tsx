import React, { useState } from 'react';
import { 
  X, 
  Check, 
  ShieldCheck, 
  Truck, 
  MapPin, 
  CheckCircle2, 
  Copy, 
  ArrowRight
} from 'lucide-react';
import { CartItem, Currency, Language, Order } from '../types';
import { formatPrice } from '../utils/currency';
import { STORE_INFO } from '../data/storeInfo';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  currency: Currency;
  language: Language;
  discountAmount: number;
  appliedPromo: string;
  onOrderSuccess: (order: Order) => void;
  onOpenOrderTracking: (orderId: string) => void;
}

const BD_DISTRICTS = [
  'Chattogram / রাউজান (চট্টগ্রাম)',
  'Dhaka (ঢাকা)',
  'Sylhet (সিলেট)',
  'Cox’s Bazar (কক্সবাজার)',
  'Cumilla (কুমিল্লা)',
  'Noakhali (নোয়াখালী)',
  'Feni (ফেনী)',
  'Gazipur (গাজীপুর)',
  'Narayanganj (নারায়ণগঞ্জ)',
  'Rajshahi (রাজশাহী)',
  'Khulna (খুলনা)',
  'Barishal (বরিশাল)',
  'Rangpur (রংপুর)',
  'Mymensingh (ময়মনসিংহ)',
  'Bogura (বগুড়া)'
];

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  currency,
  language,
  discountAmount,
  appliedPromo,
  onOrderSuccess,
  onOpenOrderTracking
}) => {
  const [customerName, setCustomerName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [district, setDistrict] = useState('Chattogram / রাউজান (চট্টগ্রাম)');
  const [address, setAddress] = useState('');
  const [deliveryNote, setDeliveryNote] = useState('');
  const [paymentMethod, setPaymentMethod] = useState<'cod' | 'bkash' | 'nagad' | 'card'>('cod');
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<Order | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  if (!isOpen) return null;
  const isBn = language === 'bn';

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);

  // Compute Shipping based on Raozan/Chattogram vs Rest of Bangladesh
  const isChattogram = district.includes('Chattogram') || district.includes('চট্টগ্রাম') || district.includes('রাউজান');
  let shippingFee = isChattogram ? STORE_INFO.shippingFees.insideChattogram : STORE_INFO.shippingFees.outsideChattogram;
  if (subtotal >= STORE_INFO.freeDeliveryThreshold) {
    shippingFee = 0;
  }

  const grandTotal = Math.max(0, subtotal - discountAmount + shippingFee);

  const handleSubmitOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim() || !phone.trim() || !address.trim()) {
      alert(isBn ? 'দয়া করে নাম, মোবাইল নম্বর এবং সম্পূর্ণ ডেলিভারি ঠিকানা দিন।' : 'Please enter your name, phone, and delivery address.');
      return;
    }

    setIsSubmitting(true);

    setTimeout(() => {
      const orderId = `ALF-${Math.floor(10000 + Math.random() * 90000)}`;
      const trackingCode = `STF-BD-${Math.floor(100000 + Math.random() * 900000)}`;

      const newOrder: Order = {
        id: orderId,
        customerName,
        phone,
        email: email || 'customer@alifshop.com.bd',
        address,
        district,
        items: [...cartItems],
        subtotal,
        shippingFee,
        discount: discountAmount,
        total: grandTotal,
        paymentMethod,
        status: 'confirmed',
        createdAt: new Date().toLocaleDateString('bn-BD', {
          year: 'numeric',
          month: 'short',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        trackingCode
      };

      setCompletedOrder(newOrder);
      setIsSubmitting(false);
      onOrderSuccess(newOrder);
    }, 1100);
  };

  const handleCopyId = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(true);
    setTimeout(() => setCopiedId(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-md animate-fadeIn">
      <div 
        className="bg-white rounded-3xl w-full max-w-4xl max-h-[92vh] overflow-hidden shadow-2xl flex flex-col relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-stone-200 bg-stone-900 text-white flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-amber-600 flex items-center justify-center text-white">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-serif font-bold tracking-wide">
                {completedOrder 
                  ? (isBn ? 'অর্ডার নিশ্চিতকরণ • আলিফ শপ' : 'Order Placed • ALIF SHOP') 
                  : (isBn ? 'আলিফ শপ এক্সপ্রেস চেকআউট' : 'ALIF SHOP Checkout')}
              </h3>
              <p className="text-xs text-stone-300">
                {isBn 
                  ? 'সরাসরি ক্যাশ অন ডেলিভারি (পণ্য হাতে পেয়ে টাকা দিন)' 
                  : 'Cash on Delivery Across Bangladesh • Fast Doorstep Delivery'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-300 hover:text-white hover:bg-stone-800 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8 overflow-y-auto flex-1">
          {completedOrder ? (
            /* Order Success View */
            <div className="text-center py-6 max-w-xl mx-auto space-y-6 animate-fadeIn">
              <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
                <CheckCircle2 className="w-10 h-10 animate-scaleIn" />
              </div>

              <div>
                <span className="text-xs uppercase font-bold tracking-widest text-amber-700">
                  {isBn ? 'আলিফ শপে কেনাকাটা করার জন্য ধন্যবাদ!' : 'THANK YOU FOR SHOPPING WITH ALIF SHOP'}
                </span>
                <h3 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 mt-1">
                  {isBn ? 'আপনার অর্ডার সফলভাবে কনফার্ম হয়েছে!' : 'Your Order Has Been Confirmed!'}
                </h3>
                <p className="text-xs sm:text-sm text-stone-600 mt-2">
                  {isBn 
                    ? `আমাদের গহিরা, রাউজান হাব থেকে আপনার পার্সেল প্যাক করা হচ্ছে। মোবাইল নম্বর: ${completedOrder.phone}` 
                    : `Your parcel is being packed at our Gohira, Raozan hub. Phone: ${completedOrder.phone}`}
                </p>
              </div>

              {/* Order ID Card */}
              <div className="p-5 rounded-2xl bg-stone-50 border border-stone-200 text-left space-y-3">
                <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                  <div>
                    <div className="text-xs text-stone-500">{isBn ? 'অর্ডার রেফারেন্স নম্বর' : 'Order ID'}</div>
                    <div className="text-xl font-mono font-bold text-amber-700">{completedOrder.id}</div>
                  </div>
                  <button
                    onClick={() => handleCopyId(completedOrder.id)}
                    className="px-3 py-1.5 text-xs rounded-lg border border-stone-300 hover:bg-stone-100 flex items-center space-x-1"
                  >
                    {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedId ? (isBn ? 'কপি হয়েছে' : 'Copied') : (isBn ? 'কপি' : 'Copy')}</span>
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <span className="text-stone-500 block">{isBn ? 'গ্রাহক' : 'Customer:'}</span>
                    <span className="font-semibold text-stone-800">{completedOrder.customerName}</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">{isBn ? 'মোট প্রদেয়' : 'Total Amount:'}</span>
                    <span className="font-bold text-stone-900 font-mono">{formatPrice(completedOrder.total, currency)}</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">{isBn ? 'পেমেন্ট মাধ্যম' : 'Payment:'}</span>
                    <span className="font-semibold text-stone-800 uppercase">{completedOrder.paymentMethod}</span>
                  </div>
                  <div>
                    <span className="text-stone-500 block">{isBn ? 'ঠিকানা' : 'Address:'}</span>
                    <span className="font-medium text-stone-800 truncate block">{completedOrder.address}, {completedOrder.district}</span>
                  </div>
                </div>
              </div>

              {/* SMS Notification */}
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 text-left text-xs font-mono text-amber-950">
                <span className="font-bold block mb-1">📩 এসএমএস কনফার্মেশন পাঠানো হয়েছে:</span>
                &ldquo;ALIF SHOP: প্রিয় {completedOrder.customerName}, আপনার অর্ডার {completedOrder.id} সফল হয়েছে। মোট প্রদেয়: {formatPrice(completedOrder.total, currency)}। গহিরা, রাউজান হটলাইন: {STORE_INFO.phoneDisplay}।&rdquo;
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <button
                  onClick={() => {
                    onClose();
                    onOpenOrderTracking(completedOrder.id);
                  }}
                  className="flex-1 py-3.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold uppercase tracking-wider transition-all flex items-center justify-center space-x-1.5 shadow-md"
                >
                  <Truck className="w-4 h-4" />
                  <span>{isBn ? 'লাইভ অর্ডার ট্র্যাক করুন' : 'Track Order Live'}</span>
                </button>

                <button
                  onClick={onClose}
                  className="px-6 py-3.5 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold uppercase tracking-wider transition-all"
                >
                  {isBn ? 'আরও পোশাক দেখুন' : 'Continue Shopping'}
                </button>
              </div>
            </div>
          ) : (
            /* Checkout Form View */
            <form onSubmit={handleSubmitOrder} className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              
              {/* Left Column: Customer & Delivery (7 cols) */}
              <div className="lg:col-span-7 space-y-6">
                <div>
                  <h4 className="text-base font-serif font-bold text-stone-900 flex items-center space-x-2 pb-3 border-b border-stone-200">
                    <span className="w-6 h-6 rounded-full bg-amber-600 text-white text-xs font-mono flex items-center justify-center">1</span>
                    <span>{isBn ? 'গ্রাহকের তথ্য ও ডেলিভারি ঠিকানা' : 'Customer & Shipping Address'}</span>
                  </h4>

                  <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 uppercase tracking-wider mb-1">
                        {isBn ? 'পূর্ণ নাম *' : 'Full Name *'}
                      </label>
                      <input
                        type="text"
                        required
                        value={customerName}
                        onChange={(e) => setCustomerName(e.target.value)}
                        placeholder="e.g. Alif"
                        className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-amber-600"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 uppercase tracking-wider mb-1">
                        {isBn ? 'মোবাইল নম্বর (১১ ডিজিট) *' : 'Mobile Phone (BD Number) *'}
                      </label>
                      <input
                        type="tel"
                        required
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="018••••••••"
                        className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm font-mono focus:bg-white focus:outline-none focus:border-amber-600"
                      />
                    </div>

                    <div>
                      <label className="block font-bold text-stone-700 uppercase tracking-wider mb-1">
                        {isBn ? 'ইমেইল (ঐচ্ছিক)' : 'Email (Optional)'}
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="customer@gmail.com"
                        className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-amber-600"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 uppercase tracking-wider mb-1">
                        {isBn ? 'জেলা নির্বাচন করুন *' : 'Select District *'}
                      </label>
                      <select
                        value={district}
                        onChange={(e) => setDistrict(e.target.value)}
                        className="w-full px-3.5 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-amber-600 font-medium"
                      >
                        {BD_DISTRICTS.map((dist) => (
                          <option key={dist} value={dist}>{dist}</option>
                        ))}
                      </select>
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-bold text-stone-700 uppercase tracking-wider mb-1">
                        {isBn ? 'সম্পূর্ণ ঠিকানা (বাসা/রোড/এলাকা/উপজেলা) *' : 'Full Delivery Address *'}
                      </label>
                      <textarea
                        required
                        rows={2}
                        value={address}
                        onChange={(e) => setAddress(e.target.value)}
                        placeholder={isBn ? 'যেমন: গহিরা বাজার, শান্তি রোড, রাউজান, চট্টগ্রাম' : 'e.g. Gohira Shanti Bazar, Raozan, Chattogram'}
                        className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-sm focus:bg-white focus:outline-none focus:border-amber-600"
                      />
                    </div>

                    <div className="sm:col-span-2">
                      <label className="block font-medium text-stone-500 uppercase tracking-wider mb-1">
                        {isBn ? 'ডেলিভারি নোট (ঐচ্ছিক)' : 'Delivery Note (Optional)'}
                      </label>
                      <input
                        type="text"
                        value={deliveryNote}
                        onChange={(e) => setDeliveryNote(e.target.value)}
                        placeholder={isBn ? 'যেমন: আসার আগে কল দিন' : 'e.g. Call before delivery'}
                        className="w-full px-3.5 py-2 bg-stone-50 border border-stone-300 rounded-xl text-xs focus:bg-white focus:outline-none"
                      />
                    </div>
                  </div>
                </div>

                {/* Payment Selection */}
                <div>
                  <h4 className="text-base font-serif font-bold text-stone-900 flex items-center space-x-2 pb-3 border-b border-stone-200">
                    <span className="w-6 h-6 rounded-full bg-amber-600 text-white text-xs font-mono flex items-center justify-center">2</span>
                    <span>{isBn ? 'পেমেন্ট মেথড নির্বাচন করুন' : 'Payment Method'}</span>
                  </h4>

                  <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                    <button
                      type="button"
                      onClick={() => setPaymentMethod('cod')}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        paymentMethod === 'cod'
                          ? 'border-amber-600 bg-amber-50 text-amber-900 ring-2 ring-amber-600 font-bold'
                          : 'border-stone-200 hover:border-stone-400 text-stone-700'
                      }`}
                    >
                      <div className="font-bold text-xs">{isBn ? 'ক্যাশ অন ডেলিভারি' : 'Cash On Delivery'}</div>
                      <div className="text-[10px] text-stone-500 mt-0.5">{isBn ? 'পণ্য পেয়ে টাকা দিন' : 'Pay on Delivery'}</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('bkash')}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        paymentMethod === 'bkash'
                          ? 'border-pink-600 bg-pink-50 text-pink-700 ring-2 ring-pink-600 font-bold'
                          : 'border-stone-200 hover:border-stone-400 text-stone-700'
                      }`}
                    >
                      <div className="font-bold text-xs text-pink-600">bKash</div>
                      <div className="text-[10px] text-stone-500 mt-0.5">{isBn ? 'বিকাশ পেমেন্ট' : 'Direct Mobile'}</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('nagad')}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        paymentMethod === 'nagad'
                          ? 'border-orange-600 bg-orange-50 text-orange-700 ring-2 ring-orange-600 font-bold'
                          : 'border-stone-200 hover:border-stone-400 text-stone-700'
                      }`}
                    >
                      <div className="font-bold text-xs text-orange-600">Nagad</div>
                      <div className="text-[10px] text-stone-500 mt-0.5">{isBn ? 'নগদ পেমেন্ট' : 'Instant'}</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setPaymentMethod('card')}
                      className={`p-3 rounded-xl border text-center transition-all ${
                        paymentMethod === 'card'
                          ? 'border-stone-900 bg-stone-100 text-stone-900 ring-2 ring-stone-900 font-bold'
                          : 'border-stone-200 hover:border-stone-400 text-stone-700'
                      }`}
                    >
                      <div className="font-bold text-xs">Visa / Master</div>
                      <div className="text-[10px] text-stone-500 mt-0.5">{isBn ? 'কার্ড পেমেন্ট' : 'Card'}</div>
                    </button>
                  </div>
                </div>
              </div>

              {/* Right Column: Order Summary (5 cols) */}
              <div className="lg:col-span-5">
                <div className="p-5 sm:p-6 bg-stone-50 rounded-2xl border border-stone-200 sticky top-4 space-y-4">
                  <h4 className="text-base font-serif font-bold text-stone-900 pb-2 border-b border-stone-200">
                    {isBn ? 'অর্ডার সামারি' : 'Order Summary'}
                  </h4>

                  <div className="max-h-52 overflow-y-auto space-y-2.5 pr-1 divide-y divide-stone-100">
                    {cartItems.map((item) => (
                      <div key={item.id} className="pt-2 flex items-center space-x-3 text-xs">
                        <img 
                          src={item.product.image} 
                          alt={item.product.title} 
                          className="w-12 h-14 rounded-lg object-cover shrink-0 border border-stone-200"
                        />
                        <div className="flex-1">
                          <div className="font-bold text-stone-900 line-clamp-1">
                            {isBn ? item.product.titleBn : item.product.title}
                          </div>
                          <div className="text-[11px] text-stone-500">
                            Size: {item.selectedSize} • Qty: {item.quantity}
                          </div>
                        </div>
                        <div className="font-mono font-bold text-stone-800">
                          {formatPrice(item.product.price * item.quantity, currency)}
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Pricing Breakdown */}
                  <div className="space-y-2 pt-3 border-t border-stone-200 text-xs text-stone-600">
                    <div className="flex justify-between">
                      <span>{isBn ? 'সাবটোটাল' : 'Subtotal'}</span>
                      <span className="font-mono font-semibold text-stone-900">
                        {formatPrice(subtotal, currency)}
                      </span>
                    </div>

                    {discountAmount > 0 && (
                      <div className="flex justify-between text-emerald-700 font-semibold">
                        <span>{isBn ? `প্রমো ডিসকাউন্ট (${appliedPromo})` : `Promo (${appliedPromo})`}</span>
                        <span className="font-mono">-{formatPrice(discountAmount, currency)}</span>
                      </div>
                    )}

                    <div className="flex justify-between">
                      <span>
                        {isChattogram 
                          ? (isBn ? 'ডেলিভারি চার্জ (রাউজান / চট্টগ্রাম)' : 'Delivery (Raozan/Chattogram)') 
                          : (isBn ? 'ডেলিভারি চার্জ (সারা দেশ)' : 'Delivery (Nationwide)')}
                      </span>
                      <span className="font-mono font-semibold text-stone-900">
                        {shippingFee === 0 ? (isBn ? 'ফ্রি' : 'FREE') : formatPrice(shippingFee, currency)}
                      </span>
                    </div>

                    <div className="flex justify-between text-base font-bold text-stone-900 pt-3 border-t border-stone-200">
                      <span>{isBn ? 'সর্বমোট প্রদেয়' : 'Total Payable'}</span>
                      <span className="font-mono text-xl text-amber-700">
                        {formatPrice(grandTotal, currency)}
                      </span>
                    </div>
                  </div>

                  {/* Submit Button */}
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full py-4 bg-amber-600 hover:bg-amber-700 disabled:opacity-60 text-white rounded-2xl text-xs sm:text-sm font-bold uppercase tracking-wider transition-all shadow-lg flex items-center justify-center space-x-2 cursor-pointer"
                  >
                    {isSubmitting ? (
                      <span>{isBn ? 'অর্ডার প্রসেস হচ্ছে...' : 'Processing...'}</span>
                    ) : (
                      <>
                        <span>{isBn ? 'অর্ডার নিশ্চিত করুন' : 'Confirm Order'}</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>

                  <div className="p-3 rounded-xl bg-white border border-stone-200 text-[11px] text-stone-600 space-y-1">
                    <div className="flex items-center space-x-1.5 text-stone-800 font-semibold">
                      <Truck className="w-4 h-4 text-amber-600" />
                      <span>{STORE_INFO.addressBn}</span>
                    </div>
                    <p className="text-[10px]">
                      সারা দেশে ক্যাশ অন ডেলিভারি এবং ৭ দিনে সহজ এক্সচেঞ্জ সুবিধা।
                    </p>
                  </div>
                </div>
              </div>

            </form>
          )}
        </div>
      </div>
    </div>
  );
};

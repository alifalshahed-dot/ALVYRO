import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight, Sparkles, MapPin, Truck, RotateCcw } from 'lucide-react';
import { Language, ProductCategory } from '../types';
import { STORE_INFO } from '../data/storeInfo';

interface HeroSliderProps {
  language: Language;
  onExplore: (category?: ProductCategory) => void;
  onOpenContact: () => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({
  language,
  onExplore,
  onOpenContact
}) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const isBn = language === 'bn';

  const slides = [
    {
      id: 1,
      badge: isBn ? '🔥 নতুন কালেকশন • ২০২৬' : '🔥 New Arrivals 2026',
      tag: isBn ? 'টি-শার্ট ও পোলো কালেকশন' : 'T-SHIRTS & POLO SHIRTS',
      headline: isBn 
        ? 'প্রিমিয়াম সুতি টি-শার্ট ও এলিগ্যান্ট পোলো' 
        : 'Premium Combed Cotton Tees & Pique Polo',
      subline: isBn 
        ? '১৮০ জিএসএম ড্রপ-শোল্ডার কটন টি-শার্ট এবং ২২০ জিএসএম ম্যাটি পিকে এক্সিকিউটিভ পোলো শার্ট।' 
        : 'Heavyweight bio-washed 180 GSM drop-shoulder tees and tailored 220 GSM pique polo shirts.',
      image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=1600&q=85',
      primaryBtn: isBn ? 'টি-শার্ট ও পোলো কিনুন' : 'Shop T-Shirts & Polo',
      secondaryBtn: isBn ? 'ক্যাটালগ দেখুন' : 'Explore Catalog',
      category: 't-shirt' as ProductCategory
    },
    {
      id: 2,
      badge: isBn ? '⚡ ট্রেন্ডিং ফ্যাশন' : '⚡ Trending Streetwear',
      headline: isBn 
        ? 'কোরিয়ান প্লিটেড প্যান্ট ও ক্যাজুয়াল ট্রাউজার্স' 
        : 'Korean Pleated Pants & Casual Trousers',
      tag: isBn ? 'প্যান্ট ও ট্রাউজার্স কালেকশন' : 'PANTS & TROUSERS COLLECTION',
      subline: isBn 
        ? 'তরুণদের পছন্দের ভাইরাল কোরিয়ান ব্যাগি প্লিটেড প্যান্ট, ড্রস্ট্রিং কার্গো এবং সফট চিনো ট্রাউজার্স।' 
        : 'Fluid draped Korean double-pleated wide pants, comfort stretch chinos, and multi-pocket cargos.',
      image: 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?auto=format&fit=crop&w=1600&q=85',
      primaryBtn: isBn ? 'কোরিয়ান প্যান্ট দেখুন' : 'View Korean Pants',
      secondaryBtn: isBn ? 'ট্রাউজার্স সংগ্রহ' : 'Casual Trousers',
      category: 'korean-pant' as ProductCategory
    },
    {
      id: 3,
      badge: isBn ? '💼 বেস্টসেলার এক্সিকিউটিভ' : '💼 Executive Bestsellers',
      headline: isBn 
        ? 'ফরমাল ও ক্যাজুয়াল শার্টের আভিজাত্য' 
        : 'Formal & Casual Shirts Masterpiece',
      tag: isBn ? 'শার্ট কালেকশন' : 'SHIRTS COLLECTION',
      subline: isBn 
        ? 'খাঁটি লিনেন কটন ক্যাজুয়াল শার্ট, কিউবান কলার ও রিঙ্কেল-ফ্রি অক্সফোর্ড অফিস ফরমাল শার্ট।' 
        : 'Breathable summer linen shirts, Cuban camp collars, and boardroom-ready Oxford cotton formal shirts.',
      image: 'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=1600&q=85',
      primaryBtn: isBn ? 'শার্ট কালেকশন দেখুন' : 'Shop Shirts',
      secondaryBtn: isBn ? 'গহিরা শোরুম' : 'Visit Raozan Store',
      category: 'casual-shirt' as ProductCategory
    }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5500);
    return () => clearInterval(timer);
  }, [slides.length]);

  return (
    <div className="relative w-full overflow-hidden bg-stone-950 text-white">
      {/* Slides Track */}
      <div 
        className="flex transition-transform duration-700 ease-out"
        style={{ transform: `translateX(-${currentSlide * 100}%)` }}
      >
        {slides.map((slide) => (
          <div key={slide.id} className="w-full shrink-0 relative min-h-[500px] md:min-h-[620px] flex items-center">
            
            {/* Background Image with dark gradient for readability */}
            <div className="absolute inset-0 z-0">
              <img 
                src={slide.image} 
                alt={slide.headline}
                className="w-full h-full object-cover object-center filter brightness-[0.65]"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-stone-950/95 via-stone-950/70 to-transparent" />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-stone-950/30" />
            </div>

            {/* Slide Text Content */}
            <div className="relative z-10 max-w-7xl mx-auto px-6 sm:px-8 lg:px-12 py-16 w-full">
              <div className="max-w-2xl space-y-5">
                
                {/* Badge */}
                <div className="inline-flex items-center space-x-2 bg-amber-600/20 backdrop-blur-md px-3.5 py-1.5 rounded-full border border-amber-500/30 text-xs font-bold uppercase tracking-widest text-amber-300">
                  <span>{slide.badge}</span>
                </div>

                {/* Subtag */}
                <div className="text-xs uppercase tracking-[0.22em] font-bold text-stone-300">
                  {slide.tag}
                </div>

                {/* Headline */}
                <h1 className="text-3xl sm:text-5xl lg:text-6xl font-serif font-extrabold tracking-tight text-white leading-[1.15]">
                  {slide.headline}
                </h1>

                {/* Subline */}
                <p className="text-sm sm:text-base text-stone-300 leading-relaxed font-light max-w-xl">
                  {slide.subline}
                </p>

                {/* Actions */}
                <div className="pt-2 flex flex-wrap gap-4 items-center">
                  <button
                    onClick={() => onExplore(slide.category)}
                    className="px-7 py-3.5 bg-amber-600 hover:bg-amber-700 text-white rounded-full text-xs sm:text-sm font-bold tracking-wider uppercase transition-all shadow-lg hover:shadow-amber-600/30 flex items-center space-x-2 cursor-pointer"
                  >
                    <span>{slide.primaryBtn}</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>

                  <button
                    onClick={() => onExplore('all')}
                    className="px-6 py-3.5 bg-white/15 hover:bg-white/25 backdrop-blur-md text-white rounded-full text-xs sm:text-sm font-bold tracking-wider uppercase transition-all border border-white/20 cursor-pointer"
                  >
                    <span>{slide.secondaryBtn}</span>
                  </button>
                </div>

              </div>
            </div>

          </div>
        ))}
      </div>

      {/* Slide Navigation Buttons */}
      <button
        onClick={() => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length)}
        className="absolute left-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-sm transition-all border border-white/10"
        aria-label="Previous Slide"
      >
        <ChevronLeft className="w-5 h-5" />
      </button>

      <button
        onClick={() => setCurrentSlide((prev) => (prev + 1) % slides.length)}
        className="absolute right-4 top-1/2 -translate-y-1/2 z-20 w-11 h-11 rounded-full bg-black/40 hover:bg-black/70 text-white flex items-center justify-center backdrop-blur-sm transition-all border border-white/10"
        aria-label="Next Slide"
      >
        <ChevronRight className="w-5 h-5" />
      </button>

      {/* Dots */}
      <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-20 flex space-x-2">
        {slides.map((_, idx) => (
          <button
            key={idx}
            onClick={() => setCurrentSlide(idx)}
            className={`h-2 rounded-full transition-all duration-300 ${
              currentSlide === idx ? 'w-8 bg-amber-500' : 'w-2 bg-white/40 hover:bg-white/70'
            }`}
            aria-label={`Go to slide ${idx + 1}`}
          />
        ))}
      </div>

      {/* Highlights Bar: Location, Cash on Delivery, Return Policy */}
      <div className="relative z-10 border-t border-white/10 bg-black/60 backdrop-blur-md py-3.5 px-6">
        <div className="max-w-7xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 text-xs text-stone-200">
          <div className="flex items-center space-x-2">
            <MapPin className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="truncate">{STORE_INFO.landmarkBn}</span>
          </div>
          <div className="flex items-center space-x-2">
            <Truck className="w-4 h-4 text-amber-400 shrink-0" />
            <span>সারা দেশে ক্যাশ অন ডেলিভারি</span>
          </div>
          <div className="flex items-center space-x-2">
            <RotateCcw className="w-4 h-4 text-amber-400 shrink-0" />
            <span>৭ দিনে সহজ পণ্য এক্সচেঞ্জ সুবিধা</span>
          </div>
          <div className="flex items-center space-x-2">
            <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
            <span>২,০০০ টাকার অর্ডারে ফ্রি ডেলিভারি</span>
          </div>
        </div>
      </div>

    </div>
  );
};

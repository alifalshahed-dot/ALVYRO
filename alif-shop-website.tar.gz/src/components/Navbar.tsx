import React, { useState, useEffect } from 'react';
import { 
  ShoppingBag, 
  Heart, 
  Search, 
  MapPin, 
  Truck, 
  Menu, 
  X, 
  Globe, 
  ChevronDown,
  Sparkles,
  PhoneCall,
  RotateCcw,
  Info
} from 'lucide-react';
import { Currency, Language, ProductCategory } from '../types';
import { formatPrice } from '../utils/currency';
import { STORE_INFO } from '../data/storeInfo';

interface NavbarProps {
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
  currency: Currency;
  setCurrency: (c: Currency) => void;
  language: Language;
  setLanguage: (l: Language) => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenAbout: () => void;
  onOpenContact: () => void;
  onOpenReturnPolicy: () => void;
  onOpenDeliveryPolicy: () => void;
  onOpenOrderTracking: () => void;
  activeCategory: ProductCategory;
  setActiveCategory: (c: ProductCategory) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  cartTotal,
  wishlistCount,
  currency,
  setCurrency,
  language,
  setLanguage,
  onOpenCart,
  onOpenWishlist,
  onOpenAbout,
  onOpenContact,
  onOpenReturnPolicy,
  onOpenDeliveryPolicy,
  onOpenOrderTracking,
  activeCategory,
  setActiveCategory,
  searchQuery,
  setSearchQuery
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showSearchInput, setShowSearchInput] = useState(false);
  const [announcementIdx, setAnnouncementIdx] = useState(0);

  const isBn = language === 'bn';

  const announcements = [
    isBn ? '✨ ALIF SHOP - গহিরা, রাউজান, চট্টগ্রাম | সেরা পুরুষ পোশাকের বিশ্বস্ত ঠিকানা' : '✨ ALIF SHOP - Gohira, Raozan, Chattogram | Premium Menswear Hub',
    isBn ? '👕 নতুন ড্রপ-শোল্ডার টি-শার্ট, প্রিমিয়াম পোলো ও কোরিয়ান প্যান্ট কালেকশন!' : '👕 New Drop-Shoulder Tees, Pique Polo & Korean Pleated Pants!',
    isBn ? '🚚 সারা দেশে ক্যাশ অন ডেলিভারি | ২,০০০ টাকার অর্ডারে ফ্রি ডেলিভারি!' : '🚚 Cash on Delivery Nationwide | FREE Shipping on orders over ৳2,000!',
    isBn ? `📞 সরাসরি অর্ডার ও জিজ্ঞাসা হটলাইন: ${STORE_INFO.phoneDisplay}` : `📞 Direct Order Hotline: ${STORE_INFO.phoneDisplay}`
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setAnnouncementIdx((prev) => (prev + 1) % announcements.length);
    }, 4000);
    return () => clearInterval(timer);
  }, [announcements.length]);

  const handleNavCategory = (cat: ProductCategory) => {
    setActiveCategory(cat);
    setMobileMenuOpen(false);
    const el = document.getElementById('catalog-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white/95 backdrop-blur-md transition-all border-b border-stone-200">
      
      {/* Top Announcement Bar */}
      <div className="bg-stone-900 text-stone-200 text-[11px] md:text-xs py-2 px-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
          
          {/* Location Badge */}
          <div className="hidden md:flex items-center space-x-4 text-stone-300">
            <button 
              onClick={onOpenContact}
              className="flex items-center space-x-1.5 hover:text-white transition-colors"
            >
              <MapPin className="w-3.5 h-3.5 text-amber-500" />
              <span>{isBn ? 'গহিরা, রাউজান, চট্টগ্রাম' : 'Gohira, Raozan, Ctg'}</span>
            </button>
            <span className="text-stone-600">|</span>
            <a 
              href={`tel:${STORE_INFO.phone}`}
              className="flex items-center space-x-1.5 hover:text-white transition-colors font-mono"
            >
              <PhoneCall className="w-3.5 h-3.5 text-emerald-400" />
              <span>{STORE_INFO.phoneDisplay}</span>
            </a>
          </div>

          {/* Center Announcement */}
          <div className="flex-1 text-center font-medium tracking-wide flex items-center justify-center space-x-2 text-white">
            <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0 animate-pulse" />
            <span className="truncate transition-opacity duration-300">
              {announcements[announcementIdx]}
            </span>
          </div>

          {/* Right Controls: Track & Lang/Currency */}
          <div className="flex items-center space-x-3 text-white font-medium">
            <button
              onClick={onOpenOrderTracking}
              className="hidden sm:flex items-center space-x-1 text-stone-300 hover:text-white text-[11px]"
            >
              <Truck className="w-3.5 h-3.5 text-amber-400" />
              <span>{isBn ? 'অর্ডার ট্র্যাকিং' : 'Track Order'}</span>
            </button>
            <span className="text-stone-600 hidden sm:inline">|</span>
            <button
              onClick={() => setCurrency(currency === 'BDT' ? 'USD' : 'BDT')}
              className="px-2 py-0.5 rounded bg-stone-800 hover:bg-stone-700 text-[10px] uppercase font-bold"
            >
              {currency === 'BDT' ? '৳ BDT' : '$ USD'}
            </button>
            <span className="text-stone-600">|</span>
            <button
              onClick={() => setLanguage(language === 'bn' ? 'en' : 'bn')}
              className="flex items-center space-x-1 hover:text-amber-300 text-[11px]"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'EN' : 'বাংলা'}</span>
            </button>
          </div>

        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Mobile Menu Button */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 -ml-2 text-stone-800 hover:text-amber-700 transition-colors"
              aria-label="Toggle menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

          {/* Brand Logo: ALIF SHOP */}
          <div 
            className="flex items-center flex-col justify-center cursor-pointer select-none"
            onClick={() => handleNavCategory('all')}
          >
            <div className="flex items-center space-x-1.5">
              <span className="font-serif tracking-[0.16em] text-2xl sm:text-3xl font-extrabold text-stone-900 hover:text-amber-700 transition-colors">
                ALIF SHOP
              </span>
            </div>
            <span className="text-[10px] uppercase tracking-[0.25em] text-amber-700 font-bold -mt-0.5">
              গহিরা, রাউজান • চট্টগ্রাম
            </span>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center space-x-6 text-xs uppercase tracking-[0.12em] font-bold text-stone-700">
            <button
              onClick={() => handleNavCategory('all')}
              className={`py-2 hover:text-amber-700 transition-colors relative ${
                activeCategory === 'all' ? 'text-amber-700 font-extrabold' : ''
              }`}
            >
              {isBn ? 'সকল পোশাক' : 'All Clothes'}
              {activeCategory === 'all' && (
                <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-amber-700 rounded-full" />
              )}
            </button>

            {/* T-Shirts & Polo Dropdown */}
            <div className="relative group py-2">
              <button
                className={`flex items-center space-x-1 hover:text-amber-700 transition-colors ${
                  activeCategory === 't-shirt' || activeCategory === 'polo-shirt' ? 'text-amber-700 font-extrabold' : ''
                }`}
              >
                <span>{isBn ? 'টি-শার্ট ও পোলো' : 'T-Shirts & Polo'}</span>
                <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
              </button>
              <div className="absolute top-full left-0 w-56 bg-white border border-stone-200 shadow-xl rounded-2xl p-3 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all duration-200">
                <button
                  onClick={() => handleNavCategory('t-shirt')}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-stone-50 hover:text-amber-700 transition-colors"
                >
                  {isBn ? 'ক্যাজুয়াল টি-শার্ট (১৮০ জিএসএম)' : 'Casual T-Shirts (180 GSM)'}
                </button>
                <button
                  onClick={() => handleNavCategory('polo-shirt')}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-stone-50 hover:text-amber-700 transition-colors"
                >
                  {isBn ? 'প্রিমিয়াম পোলো টি-শার্ট (২২০ জিএসএম)' : 'Premium Polo Shirts'}
                </button>
              </div>
            </div>

            {/* Shirts Dropdown */}
            <div className="relative group py-2">
              <button
                className={`flex items-center space-x-1 hover:text-amber-700 transition-colors ${
                  activeCategory === 'casual-shirt' || activeCategory === 'formal-shirt' ? 'text-amber-700 font-extrabold' : ''
                }`}
              >
                <span>{isBn ? 'শার্ট কালেকশন' : 'Shirts'}</span>
                <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
              </button>
              <div className="absolute top-full left-0 w-56 bg-white border border-stone-200 shadow-xl rounded-2xl p-3 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all duration-200">
                <button
                  onClick={() => handleNavCategory('casual-shirt')}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-stone-50 hover:text-amber-700 transition-colors"
                >
                  {isBn ? 'ক্যাজুয়াল শার্ট (লিনেন/কিউবান)' : 'Casual Shirts (Linen/Cuban)'}
                </button>
                <button
                  onClick={() => handleNavCategory('formal-shirt')}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-stone-50 hover:text-amber-700 transition-colors"
                >
                  {isBn ? 'ফরমাল শার্ট (অক্সফোর্ড কটন)' : 'Formal Shirts (Oxford Cotton)'}
                </button>
              </div>
            </div>

            {/* Pants Dropdown */}
            <div className="relative group py-2">
              <button
                className={`flex items-center space-x-1 hover:text-amber-700 transition-colors ${
                  activeCategory === 'korean-pant' || activeCategory === 'formal-pant' || activeCategory === 'casual-trouser' ? 'text-amber-700 font-extrabold' : ''
                }`}
              >
                <span>{isBn ? 'প্যান্ট কালেকশন' : 'Pants'}</span>
                <ChevronDown className="w-3.5 h-3.5 group-hover:rotate-180 transition-transform duration-200" />
              </button>
              <div className="absolute top-full left-0 w-60 bg-white border border-stone-200 shadow-xl rounded-2xl p-3 opacity-0 pointer-events-none group-hover:opacity-100 group-hover:pointer-events-auto transition-all duration-200">
                <button
                  onClick={() => handleNavCategory('korean-pant')}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-stone-50 hover:text-amber-700 transition-colors flex items-center justify-between"
                >
                  <span>{isBn ? 'কোরিয়ান প্যান্ট (প্লিটেড ব্যাগি)' : 'Korean Pleated Pants'}</span>
                  <span className="text-[9px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-black">HOT</span>
                </button>
                <button
                  onClick={() => handleNavCategory('formal-pant')}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-stone-50 hover:text-amber-700 transition-colors"
                >
                  {isBn ? 'ফরমাল প্যান্ট (৪-ওয়ে স্ট্রেচ)' : 'Formal Gabardine Pants'}
                </button>
                <button
                  onClick={() => handleNavCategory('casual-trouser')}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-stone-50 hover:text-amber-700 transition-colors"
                >
                  {isBn ? 'ক্যাজুয়াল ট্রাউজার্স (চিনো/কার্গো)' : 'Casual Trousers (Chino)'}
                </button>
              </div>
            </div>

            {/* Quick Policy & Info Modals */}
            <button
              onClick={onOpenAbout}
              className="py-2 hover:text-amber-700 transition-colors"
            >
              {isBn ? 'এবাউট আস' : 'About'}
            </button>

            <button
              onClick={onOpenContact}
              className="py-2 hover:text-amber-700 transition-colors"
            >
              {isBn ? 'কন্টাক্ট' : 'Contact'}
            </button>

            <button
              onClick={onOpenReturnPolicy}
              className="py-2 hover:text-amber-700 transition-colors"
            >
              {isBn ? 'রিটার্ন পলিসি' : 'Return Policy'}
            </button>

            <button
              onClick={onOpenDeliveryPolicy}
              className="py-2 hover:text-amber-700 transition-colors"
            >
              {isBn ? 'ডেলিভারি' : 'Delivery'}
            </button>
          </nav>

          {/* Action Icons */}
          <div className="flex items-center space-x-3 sm:space-x-4">
            
            {/* Search Input */}
            <div className="relative">
              {showSearchInput ? (
                <div className="flex items-center bg-stone-100 rounded-full px-3 py-1.5 border border-stone-300 w-44 sm:w-60 animate-fadeIn">
                  <Search className="w-4 h-4 text-stone-500 mr-2 shrink-0" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder={isBn ? 'টি-শার্ট, প্যান্ট, শার্ট...' : 'Search shirts, polo...'}
                    className="bg-transparent text-xs w-full focus:outline-none text-stone-800"
                    autoFocus
                  />
                  <button 
                    onClick={() => {
                      setSearchQuery('');
                      setShowSearchInput(false);
                    }}
                    className="text-stone-400 hover:text-stone-700 ml-1"
                  >
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowSearchInput(true)}
                  className="p-2 text-stone-700 hover:text-amber-700 hover:bg-stone-100 rounded-full transition-colors"
                  aria-label="Search"
                >
                  <Search className="w-5 h-5" />
                </button>
              )}
            </div>

            {/* Wishlist */}
            <button
              onClick={onOpenWishlist}
              className="p-2 text-stone-700 hover:text-amber-700 hover:bg-stone-100 rounded-full transition-colors relative"
              aria-label="Wishlist"
            >
              <Heart className="w-5 h-5" />
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 rounded-full bg-amber-600 text-white text-[10px] font-bold flex items-center justify-center animate-scaleIn">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart Trigger */}
            <button
              onClick={onOpenCart}
              className="flex items-center space-x-2 bg-stone-900 hover:bg-amber-700 text-white px-3.5 sm:px-4 py-2.5 rounded-full transition-all shadow-sm group"
              aria-label="Shopping Cart"
            >
              <div className="relative">
                <ShoppingBag className="w-4 h-4" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 w-4 h-4 rounded-full bg-amber-400 text-stone-900 text-[10px] font-extrabold flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </div>
              <span className="text-xs font-bold font-mono tracking-tight">
                {cartTotal > 0 ? formatPrice(cartTotal, currency) : (isBn ? 'ব্যাগ' : 'Cart')}
              </span>
            </button>

          </div>

        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-white px-5 py-6 space-y-4 animate-fadeIn">
          <div className="grid grid-cols-2 gap-2 pb-4 border-b border-stone-100 text-xs font-bold">
            <button
              onClick={() => handleNavCategory('all')}
              className="p-2.5 bg-stone-900 text-white rounded-xl text-center"
            >
              {isBn ? 'সকল পোশাক' : 'All Items'}
            </button>
            <button
              onClick={() => handleNavCategory('t-shirt')}
              className="p-2.5 bg-stone-100 text-stone-800 hover:bg-stone-200 rounded-xl text-center"
            >
              {isBn ? 'টি-শার্ট ও পোলো' : 'T-Shirts & Polo'}
            </button>
            <button
              onClick={() => handleNavCategory('casual-shirt')}
              className="p-2.5 bg-stone-100 text-stone-800 hover:bg-stone-200 rounded-xl text-center"
            >
              {isBn ? 'ক্যাজুয়াল ও ফরমাল শার্ট' : 'Shirts'}
            </button>
            <button
              onClick={() => handleNavCategory('korean-pant')}
              className="p-2.5 bg-amber-600 text-white rounded-xl text-center"
            >
              {isBn ? 'কোরিয়ান ও ফরমাল প্যান্ট' : 'Pants'}
            </button>
          </div>

          <div className="space-y-1.5 text-xs font-semibold text-stone-700">
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenAbout(); }}
              className="w-full text-left py-2 px-3 rounded-lg hover:bg-stone-50 flex items-center space-x-2"
            >
              <Info className="w-4 h-4 text-stone-500" />
              <span>{isBn ? 'এবাউট আস (আলিফ শপ)' : 'About Us'}</span>
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenContact(); }}
              className="w-full text-left py-2 px-3 rounded-lg hover:bg-stone-50 flex items-center space-x-2"
            >
              <PhoneCall className="w-4 h-4 text-stone-500" />
              <span>{isBn ? 'কন্টাক্ট আস ও শোরুম (গহিরা, রাউজান)' : 'Contact & Location'}</span>
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenReturnPolicy(); }}
              className="w-full text-left py-2 px-3 rounded-lg hover:bg-stone-50 flex items-center space-x-2"
            >
              <RotateCcw className="w-4 h-4 text-stone-500" />
              <span>{isBn ? 'রিটার্ন ও এক্সচেঞ্জ পলিসি (৭ দিন)' : 'Return Policy'}</span>
            </button>
            <button
              onClick={() => { setMobileMenuOpen(false); onOpenDeliveryPolicy(); }}
              className="w-full text-left py-2 px-3 rounded-lg hover:bg-stone-50 flex items-center space-x-2"
            >
              <Truck className="w-4 h-4 text-stone-500" />
              <span>{isBn ? 'ডেলিভারি পলিসি (ক্যাশ অন ডেলিভারি)' : 'Delivery Policy'}</span>
            </button>
          </div>

          <div className="pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-600">
            <span>রাউজান হটলাইন:</span>
            <a href={`tel:${STORE_INFO.phone}`} className="font-bold text-amber-700 font-mono">
              {STORE_INFO.phoneDisplay}
            </a>
          </div>
        </div>
      )}

    </header>
  );
};

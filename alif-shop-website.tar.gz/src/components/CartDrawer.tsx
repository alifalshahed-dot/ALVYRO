import React, { useState } from 'react';
import { 
  X, 
  ShoppingBag, 
  Trash2, 
  Minus, 
  Plus, 
  ArrowRight, 
  Sparkles, 
  Tag, 
  Check, 
  Truck,
  ShieldCheck 
} from 'lucide-react';
import { CartItem, Currency, Language } from '../types';
import { formatPrice } from '../utils/currency';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  currency: Currency;
  language: Language;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onProceedToCheckout: () => void;
  appliedPromo: string;
  setAppliedPromo: (promo: string) => void;
  discountAmount: number;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  cartItems,
  currency,
  language,
  onUpdateQuantity,
  onRemoveItem,
  onProceedToCheckout,
  appliedPromo,
  setAppliedPromo,
  discountAmount
}) => {
  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState('');
  const [promoSuccess, setPromoSuccess] = useState('');

  if (!isOpen) return null;

  const isBn = language === 'bn';

  const subtotal = cartItems.reduce((acc, item) => acc + item.product.price * item.quantity, 0);
  const freeShippingThreshold = 2000;
  const progressToFreeShipping = Math.min(100, Math.round((subtotal / freeShippingThreshold) * 100));
  const remainingForFreeShipping = Math.max(0, freeShippingThreshold - subtotal);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = promoInput.trim().toUpperCase();
    if (!clean) return;

    if (clean === 'ALIF10' || clean === 'ALIFSHOP' || clean === 'AMIRA10') {
      setAppliedPromo(clean);
      setPromoSuccess(isBn ? '১০% বিশেষ ডিসকাউন্ট যোগ হয়েছে!' : '10% privilege discount applied!');
      setPromoError('');
    } else {
      setPromoError(isBn ? 'ভুল ভাউচার কোড! চেষ্টা করুন: ALIF10' : 'Invalid code. Try using: ALIF10');
      setPromoSuccess('');
    }
  };

  const handleRemovePromo = () => {
    setAppliedPromo('');
    setPromoSuccess('');
    setPromoInput('');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col justify-between">
          
          {/* Header */}
          <div className="p-6 border-b border-stone-200 bg-stone-50 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-full bg-[#782333]/10 flex items-center justify-center text-[#782333]">
                <ShoppingBag className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-xl font-serif font-bold text-stone-900">
                  {isBn ? 'আপনার শপিং ব্যাগ' : 'Your Shopping Bag'}
                </h3>
                <p className="text-xs text-stone-500 font-mono">
                  {cartItems.reduce((acc, i) => acc + i.quantity, 0)} {isBn ? 'টি আইটেম' : 'items'}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-stone-400 hover:text-stone-800 hover:bg-stone-200 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Free Shipping Meter */}
          <div className="p-4 bg-amber-50/80 border-b border-amber-200/80 text-xs text-stone-800">
            {subtotal >= freeShippingThreshold ? (
              <div className="flex items-center space-x-2 text-emerald-800 font-bold">
                <Truck className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>
                  {isBn 
                    ? '🎉 অভিনন্দন! আপনার অর্ডারে ফ্রি ডেলিভারি আনলক হয়েছে!' 
                    : '🎉 Congratulations! You have unlocked FREE Nationwide Delivery!'}
                </span>
              </div>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-1.5 font-medium">
                  <span className="flex items-center space-x-1.5 text-stone-700">
                    <Truck className="w-4 h-4 text-[#782333]" />
                    <span>
                      {isBn 
                        ? `ফ্রি ডেলিভারির জন্য আর ${formatPrice(remainingForFreeShipping, currency)} যোগ করুন!` 
                        : `Add ${formatPrice(remainingForFreeShipping, currency)} more to get FREE shipping!`}
                    </span>
                  </span>
                  <span className="font-bold text-[#782333]">{progressToFreeShipping}%</span>
                </div>
                <div className="w-full bg-stone-200 rounded-full h-2 overflow-hidden">
                  <div 
                    className="bg-[#782333] h-full rounded-full transition-all duration-500"
                    style={{ width: `${progressToFreeShipping}%` }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Cart Item List */}
          <div className="p-6 overflow-y-auto flex-1 divide-y divide-stone-100">
            {cartItems.length === 0 ? (
              <div className="text-center py-20">
                <div className="w-16 h-16 rounded-full bg-stone-100 flex items-center justify-center text-stone-400 mx-auto mb-4">
                  <ShoppingBag className="w-8 h-8" />
                </div>
                <h4 className="text-lg font-serif font-bold text-stone-800">
                  {isBn ? 'আপনার ব্যাগ খালি' : 'Your bag is empty'}
                </h4>
                <p className="text-xs text-stone-500 mt-1 max-w-xs mx-auto">
                  {isBn 
                    ? 'আমাদের নতুন কালেকশন ঘুরে দেখুন এবং পছন্দের পোশাক ব্যাগে যোগ করুন।' 
                    : 'Discover our newest festive collections and add iconic styles to your bag.'}
                </p>
                <button
                  onClick={onClose}
                  className="mt-6 px-6 py-2.5 bg-[#782333] text-white rounded-full text-xs font-bold uppercase tracking-wider hover:bg-[#601927] transition-all"
                >
                  {isBn ? 'শপিং শুরু করুন' : 'Start Shopping'}
                </button>
              </div>
            ) : (
              cartItems.map((item) => (
                <div key={item.id} className="py-4 flex space-x-4 first:pt-0 last:pb-0">
                  {/* Thumbnail */}
                  <img
                    src={item.product.image}
                    alt={item.product.title}
                    className="w-20 h-26 rounded-xl object-cover object-top border border-stone-200 shrink-0"
                  />

                  {/* Details */}
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-start justify-between">
                        <h4 className="text-sm font-serif font-bold text-stone-900 line-clamp-1">
                          {isBn ? item.product.titleBn : item.product.title}
                        </h4>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-stone-400 hover:text-rose-600 p-1"
                          title="Remove item"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>

                      <div className="flex items-center space-x-3 text-xs text-stone-500 mt-1">
                        <span className="bg-stone-100 px-2 py-0.5 rounded font-mono font-bold text-stone-800">
                          Size: {item.selectedSize}
                        </span>
                        <span className="truncate max-w-[120px]">{item.selectedColor}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-3 pt-2">
                      {/* Quantity stepper */}
                      <div className="flex items-center border border-stone-300 rounded-lg overflow-hidden bg-white">
                        <button
                          onClick={() => onUpdateQuantity(item.id, -1)}
                          className="p-1 px-2 text-stone-600 hover:bg-stone-100"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-2 text-xs font-mono font-bold">{item.quantity}</span>
                        <button
                          onClick={() => onUpdateQuantity(item.id, 1)}
                          className="p-1 px-2 text-stone-600 hover:bg-stone-100"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      {/* Item Total */}
                      <span className="text-sm font-bold font-mono text-stone-900">
                        {formatPrice(item.product.price * item.quantity, currency)}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Action */}
          {cartItems.length > 0 && (
            <div className="p-6 border-t border-stone-200 bg-stone-50 space-y-4">
              {/* Promo voucher input */}
              <div>
                {!appliedPromo ? (
                  <form onSubmit={handleApplyPromo} className="flex gap-2">
                    <div className="relative flex-1">
                      <Tag className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400" />
                      <input
                        type="text"
                        value={promoInput}
                        onChange={(e) => setPromoInput(e.target.value)}
                        placeholder={isBn ? 'ভাউচার কোড (AMIRA10)' : 'Promo Code (AMIRA10)'}
                        className="w-full pl-9 pr-3 py-2 bg-white border border-stone-300 rounded-xl text-xs uppercase font-semibold focus:outline-none focus:ring-1 focus:ring-[#782333]"
                      />
                    </div>
                    <button
                      type="submit"
                      className="px-4 py-2 bg-stone-900 hover:bg-[#782333] text-white rounded-xl text-xs font-bold uppercase transition-colors"
                    >
                      {isBn ? 'যোগ' : 'Apply'}
                    </button>
                  </form>
                ) : (
                  <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 flex items-center justify-between text-xs text-emerald-800">
                    <span className="flex items-center space-x-1.5 font-bold">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>{appliedPromo} (-10%)</span>
                    </span>
                    <button
                      onClick={handleRemovePromo}
                      className="text-emerald-700 hover:text-rose-600 underline font-semibold"
                    >
                      {isBn ? 'বাতিল' : 'Remove'}
                    </button>
                  </div>
                )}
                {promoError && <p className="text-[11px] text-rose-600 mt-1 font-medium">{promoError}</p>}
                {promoSuccess && <p className="text-[11px] text-emerald-700 mt-1 font-medium">{promoSuccess}</p>}
              </div>

              {/* Price summary */}
              <div className="space-y-1.5 text-xs text-stone-600 pt-2 border-t border-stone-200">
                <div className="flex justify-between">
                  <span>{isBn ? 'সাবটোটাল' : 'Subtotal'}</span>
                  <span className="font-mono font-semibold text-stone-900">
                    {formatPrice(subtotal, currency)}
                  </span>
                </div>
                {discountAmount > 0 && (
                  <div className="flex justify-between text-emerald-700 font-semibold">
                    <span>{isBn ? 'প্রমো ডিসকাউন্ট' : 'Voucher Privilege (-10%)'}</span>
                    <span className="font-mono">
                      -{formatPrice(discountAmount, currency)}
                    </span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>{isBn ? 'শিপিং (ঢাকার ভেতরে/বাইরে)' : 'Shipping Estimate'}</span>
                  <span className="font-medium text-stone-800">
                    {subtotal >= freeShippingThreshold 
                      ? (isBn ? 'ফ্রি' : 'FREE') 
                      : (isBn ? '৳৮০ / ৳১৫০' : '৳80 / ৳150')}
                  </span>
                </div>
                <div className="flex justify-between text-base font-bold text-stone-900 pt-2 border-t border-stone-200">
                  <span>{isBn ? 'সর্বমোট প্রদেয়' : 'Estimated Total'}</span>
                  <span className="font-mono text-xl text-[#782333]">
                    {formatPrice(Math.max(0, subtotal - discountAmount), currency)}
                  </span>
                </div>
              </div>

              {/* Checkout CTA */}
              <button
                onClick={onProceedToCheckout}
                className="w-full py-4 bg-[#782333] hover:bg-[#601927] text-white rounded-2xl text-xs sm:text-sm font-bold uppercase tracking-wider transition-all shadow-lg hover:shadow-[#782333]/30 flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>{isBn ? 'চেকআউট এগিয়ে যান' : 'Proceed to Checkout'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center space-x-2 text-[11px] text-stone-500 text-center">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-400" />
                <span>{isBn ? 'ক্যাশ অন ডেলিভারি ও নিরাপদ বিকাশ পেমেন্ট' : 'Secure Checkout with bKash, Nagad & Cash on Delivery'}</span>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

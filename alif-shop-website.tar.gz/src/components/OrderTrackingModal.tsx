import React, { useState } from 'react';
import { X, Search, PackageCheck, Truck, CheckCircle2, Clock, MapPin, AlertCircle } from 'lucide-react';
import { Language } from '../types';
import { STORE_INFO } from '../data/storeInfo';

interface OrderTrackingModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
  presetOrderId?: string;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  onClose,
  language,
  presetOrderId
}) => {
  const [query, setQuery] = useState(presetOrderId || '');
  const [trackingData, setTrackingData] = useState<{
    orderId: string;
    customerName: string;
    phone: string;
    courier: string;
    trackingCode: string;
    status: 'confirmed' | 'processing' | 'shipped' | 'delivered';
    estimatedDelivery: string;
    itemsCount: number;
    amount: string;
    city: string;
    timeline: { title: string; time: string; completed: boolean }[];
  } | null>(() => {
    if (presetOrderId) {
      return {
        orderId: presetOrderId,
        customerName: 'সম্মানিত গ্রাহক',
        phone: '018•••••••92',
        courier: 'Steadfast Courier (Raozan Hub)',
        trackingCode: 'STF-BD-893120',
        status: 'processing',
        estimatedDelivery: '২৪-৪৮ ঘণ্টার মধ্যে ডেলিভারি',
        itemsCount: 2,
        amount: '৳১,৯৮০',
        city: 'Chattogram',
        timeline: [
          { title: 'অর্ডার গৃহীত ও ভেরিফাইড', time: 'আজ, ১০:১৫ AM', completed: true },
          { title: 'গহিরা শপ থেকে প্যাকেজিং সম্পন্ন', time: 'আজ, ০১:৩০ PM', completed: true },
          { title: 'কুরিয়ারে হস্তান্তর করা হয়েছে', time: 'প্রক্রিয়াধীন', completed: false },
          { title: 'ডেলিভারি রাইডারের নিকট', time: 'আগামীকাল', completed: false },
          { title: 'ডেলিভারি সম্পন্ন', time: 'অপেক্ষমাণ', completed: false }
        ]
      };
    }
    return null;
  });

  const [hasSearched, setHasSearched] = useState(false);

  if (!isOpen) return null;

  const isBn = language === 'bn';

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setHasSearched(true);
    const cleanQuery = query.trim().toUpperCase();
    setTrackingData({
      orderId: cleanQuery.startsWith('ALF-') ? cleanQuery : `ALF-${cleanQuery}`,
      customerName: 'Alif Shop Patron',
      phone: '018•••••••14',
      courier: 'Steadfast Courier Bangladesh',
      trackingCode: `STF-BD-${Math.floor(100000 + Math.random() * 900000)}`,
      status: 'shipped',
      estimatedDelivery: '২৪ থেকে ৪৮ ঘণ্টার মধ্যে ডেলিভারি',
      itemsCount: 2,
      amount: '৳১,৭৩০',
      city: 'Raozan / Chattogram',
      timeline: [
        { title: isBn ? 'অর্ডার সফলভাবে কনফার্ম হয়েছে' : 'Order Placed & Verified', time: 'গতকাল, ০৪:৩০ PM', completed: true },
        { title: isBn ? 'গহিরা, রাউজান হাব থেকে প্যাকেজিং সম্পন্ন' : 'Packed at Gohira Hub', time: 'আজ, ১১:২০ AM', completed: true },
        { title: isBn ? 'কুরিয়ার সার্ভিসে হস্তান্তর' : 'Handed to Express Courier', time: 'আজ, ০৩:৪৫ PM', completed: true },
        { title: isBn ? 'রাইডার ডেলিভারির উদ্দেশ্যে বের হয়েছে' : 'Out with Delivery Rider', time: isBn ? 'চলমান' : 'In Transit', completed: false },
        { title: isBn ? 'ডেলিভারি সম্পন্ন' : 'Delivered to Doorstep', time: isBn ? 'অপেক্ষমাণ' : 'Pending', completed: false }
      ]
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
      <div 
        className="bg-white rounded-2xl w-full max-w-xl max-h-[90vh] overflow-hidden shadow-2xl flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-6 border-b border-stone-200 flex items-center justify-between bg-stone-900 text-white">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-full bg-[#782333] flex items-center justify-center text-white">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-serif font-bold tracking-wide">
                {isBn ? 'অর্ডার ট্র্যাকিং' : 'Track Your AMIRÁ Order'}
              </h3>
              <p className="text-xs text-stone-300">
                {isBn ? 'আপনার অর্ডার নম্বর বা ফোন নম্বর দিন' : 'Enter Order ID (e.g. AMR-2049) or Mobile Number'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="p-2 text-stone-300 hover:text-white hover:bg-stone-800 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-5 border-b border-stone-100 bg-stone-50">
          <form onSubmit={handleSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-stone-400" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={isBn ? 'অর্ডার আইডি দিন (যেমন: AMR-8491)' : 'Enter Order ID (e.g. AMR-8491)...'}
                className="w-full pl-10 pr-4 py-2.5 bg-white border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#782333]/30 focus:border-[#782333]"
              />
            </div>
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#782333] hover:bg-[#621a28] text-white rounded-xl text-sm font-semibold transition-colors flex items-center space-x-1.5 shrink-0"
            >
              <span>{isBn ? 'ট্র্যাক করুন' : 'Track'}</span>
            </button>
          </form>

          {!trackingData && (
            <div className="mt-2 flex items-center gap-1.5 text-xs text-stone-500">
              <span>Quick try:</span>
              <button 
                type="button" 
                onClick={() => { setQuery('AMR-89240'); }} 
                className="underline hover:text-[#782333] font-medium"
              >
                AMR-89240
              </button>
              <span>or</span>
              <button 
                type="button" 
                onClick={() => { setQuery('AMR-31904'); }} 
                className="underline hover:text-[#782333] font-medium"
              >
                AMR-31904
              </button>
            </div>
          )}
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto flex-1">
          {trackingData ? (
            <div className="space-y-6">
              {/* Summary Card */}
              <div className="p-4 rounded-xl bg-stone-50 border border-stone-200 flex flex-wrap justify-between gap-3 text-sm">
                <div>
                  <div className="text-xs text-stone-500">{isBn ? 'অর্ডার নম্বর' : 'Order ID'}</div>
                  <div className="font-bold text-[#782333] font-mono text-base">{trackingData.orderId}</div>
                </div>
                <div>
                  <div className="text-xs text-stone-500">{isBn ? 'কুরিয়ার পার্টনার' : 'Courier'}</div>
                  <div className="font-medium text-stone-800">{trackingData.courier}</div>
                </div>
                <div>
                  <div className="text-xs text-stone-500">{isBn ? 'কুরিয়ার ট্র্যাকিং কোড' : 'Tracking Ref'}</div>
                  <div className="font-mono text-stone-800 text-xs font-semibold">{trackingData.trackingCode}</div>
                </div>
                <div>
                  <div className="text-xs text-stone-500">{isBn ? 'আনুমানিক ডেলিভারি' : 'Estimated Delivery'}</div>
                  <div className="font-medium text-emerald-700">{trackingData.estimatedDelivery}</div>
                </div>
              </div>

              {/* Stepper Timeline */}
              <div className="space-y-4 pt-2">
                <h4 className="text-xs font-bold uppercase tracking-wider text-stone-500">
                  {isBn ? 'লাইভ ডেলিভারি স্ট্যাটাস' : 'Live Shipment Timeline'}
                </h4>
                <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
                  {trackingData.timeline.map((step, idx) => (
                    <div key={idx} className="relative flex items-start space-x-3 text-sm">
                      <div 
                        className={`absolute -left-6 top-0.5 w-5 h-5 rounded-full flex items-center justify-center ${
                          step.completed
                            ? 'bg-emerald-600 text-white'
                            : 'bg-stone-200 text-stone-400'
                        }`}
                      >
                        {step.completed ? (
                          <CheckCircle2 className="w-3.5 h-3.5" />
                        ) : (
                          <Clock className="w-3 h-3" />
                        )}
                      </div>
                      <div>
                        <div className={`font-semibold ${step.completed ? 'text-stone-900' : 'text-stone-400'}`}>
                          {step.title}
                        </div>
                        <div className="text-xs text-stone-500">{step.time}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Support note */}
              <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200 flex items-start space-x-3 text-xs text-stone-700">
                <PackageCheck className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-stone-900">
                    {isBn ? 'জরুরি ডেলিভারি বা ঠিকানার পরিবর্তন প্রয়োজন?' : 'Need urgent assistance or delivery address change?'}
                  </p>
                  <p className="mt-0.5 text-stone-600">
                    {isBn ? 'আলিফ শপ হটলাইনে কল করুন: ' : 'Call ALIF SHOP Hotline: '}
                    <a href={`tel:${STORE_INFO.phone}`} className="text-amber-700 font-bold underline">{STORE_INFO.phoneDisplay}</a> (সকাল ৯টা - রাত ১০টা)
                  </p>
                </div>
              </div>
            </div>
          ) : hasSearched ? (
            <div className="text-center py-10">
              <AlertCircle className="w-10 h-10 text-amber-500 mx-auto mb-3" />
              <p className="text-sm font-semibold text-stone-800">
                {isBn ? 'কোন তথ্য পাওয়া যায়নি।' : 'No tracking record found for this Order ID.'}
              </p>
              <p className="text-xs text-stone-500 mt-1">
                {isBn ? 'অনুগ্রহ করে অর্ডার নম্বরটি পরীক্ষা করে আবার চেষ্টা করুন।' : 'Please check your order confirmation SMS or email.'}
              </p>
            </div>
          ) : (
            <div className="text-center py-12 text-stone-400">
              <Truck className="w-12 h-12 mx-auto mb-3 opacity-40 text-stone-600" />
              <p className="text-sm font-medium text-stone-600">
                {isBn ? 'উপরে আপনার অর্ডার নম্বর দিয়ে সার্চ করুন' : 'Enter your Order ID above to check live courier progress'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

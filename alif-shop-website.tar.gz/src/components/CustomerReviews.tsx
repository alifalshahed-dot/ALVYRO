import React from 'react';
import { Star, CheckCircle, Quote } from 'lucide-react';
import { Language } from '../types';

interface CustomerReviewsProps {
  language: Language;
}

export const CustomerReviews: React.FC<CustomerReviewsProps> = ({ language }) => {
  const isBn = language === 'bn';

  const reviews = [
    {
      id: 1,
      author: 'Mohammad Farhan',
      city: 'গহিরা, রাউজান',
      rating: 5,
      product: 'কোরিয়ান প্লিটেড ওয়াইড-লেগ ব্যাগি ট্রাউজার্স',
      text: isBn 
        ? 'গহিরায় আলিফ শপের আউটলেট থেকে কোরিয়ান প্যান্টটা নিয়েছিলাম। কাপড়টা অসাধারণ সফট এবং ফিটিং অসম্ভব সুন্দর। দামও অনেক রিজনেবল।' 
        : 'Bought the Korean pleated pants directly from their Gohira store. The drape and comfort are top tier! Highly recommended.',
      date: 'Verified Patron • ২ দিন আগে'
    },
    {
      id: 2,
      author: 'Shahidul Islam',
      city: 'পাহাড়তলী, রাউজান',
      rating: 5,
      product: 'ক্লাসিক পিকের কটন এক্সিকিউটিভ পোলো শার্ট',
      text: isBn 
        ? '২২০ জিএসএম ম্যাটি পিকে পোলো টি-শার্ট। কলার ওয়াশের পরও নষ্ট হয়নি। কালার একেবারে ছবির মতোই ব্রাইট। রাউজানের ভিতরে দ্রুত ডেলিভারি পেয়েছি।' 
        : 'Premium 220 GSM pique polo. The collar retains shape even after multiple washes. Excellent quality in Raozan!',
      date: 'Verified Patron • ১ সপ্তাহ আগে'
    },
    {
      id: 3,
      author: 'Tanvir Ahmed',
      city: 'জিইসি মোড়, চট্টগ্রাম',
      rating: 5,
      product: 'টেইলর্ড ৪-ওয়ে স্ট্রেচ গ্যাবার্ডিন ফরমাল প্যান্ট ও শার্ট',
      text: isBn 
        ? 'অনলাইনে অর্ডার করার ২৪ ঘণ্টার মধ্যেই চট্টগ্রাম শহরে ক্যাশ অন ডেলিভারিতে পার্সেল পেয়েছি। অফিসের জন্য বেস্ট গ্যাবার্ডিন প্যান্ট।' 
        : 'Received my order in Chittagong city in 24 hours with Cash on Delivery. Superb 4-way stretch fabric for daily office wear.',
      date: 'Verified Patron • ৩ দিন আগে'
    }
  ];

  return (
    <section className="py-16 bg-[#FAF8F5] border-t border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-amber-700 text-xs font-bold uppercase tracking-[0.2em] mb-2 inline-block">
            {isBn ? 'গ্রাহকদের সন্তুষ্টি ও অভিজ্ঞতা' : 'CUSTOMER SATISFACTION'}
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-stone-900">
            {isBn ? 'আলিফ শপের পোশাক নিয়ে গ্রাহকদের রিভিউ' : 'Loved by Patrons in Raozan & Across Bangladesh'}
          </h2>
          <div className="mt-3 flex items-center justify-center space-x-1 text-amber-500">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-5 h-5 fill-current" />
            ))}
            <span className="text-xs font-bold text-stone-700 ml-2">4.9 / 5.0 (গহিরা, রাউজান ও সারাদেশে বিশ্বস্ত)</span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((rev) => (
            <div 
              key={rev.id}
              className="bg-white p-6 rounded-3xl border border-stone-200 shadow-sm hover:shadow-md transition-shadow relative flex flex-col justify-between"
            >
              <Quote className="w-8 h-8 text-amber-600/15 absolute top-5 right-5" />

              <div>
                <div className="flex text-amber-500 mb-3">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>

                <p className="text-xs sm:text-sm text-stone-700 leading-relaxed italic">
                  &ldquo;{rev.text}&rdquo;
                </p>

                <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-amber-700 font-bold">
                  {rev.product}
                </div>
              </div>

              <div className="mt-6 flex items-center justify-between pt-4 border-t border-stone-100">
                <div>
                  <h4 className="text-sm font-bold text-stone-900">{rev.author}</h4>
                  <p className="text-[11px] text-stone-500">{rev.city}</p>
                </div>
                <div className="flex items-center space-x-1 text-[11px] text-emerald-700 font-semibold bg-emerald-50 px-2.5 py-0.5 rounded-full">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>{isBn ? 'ভেরিফাইড' : 'Verified'}</span>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

import React, { useState, useEffect } from 'react';
import { 
  X, 
  Heart, 
  ShoppingBag, 
  Sparkles, 
  Ruler, 
  Truck, 
  RotateCcw, 
  ShieldCheck, 
  Star, 
  Minus, 
  Plus, 
  Check, 
  Share2
} from 'lucide-react';
import { Product, Currency, Language } from '../types';
import { formatPrice } from '../utils/currency';
import { STORE_INFO } from '../data/storeInfo';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  currency: Currency;
  language: Language;
  isWishlisted: boolean;
  onToggleWishlist: (p: Product) => void;
  onAddToCart: (p: Product, size: string, color: string, qty: number) => void;
  onBuyNow: (p: Product, size: string, color: string, qty: number) => void;
  onOpenSizeChart: (group?: 't-shirts-polo' | 'shirts' | 'pants') => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  currency,
  language,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
  onOpenSizeChart
}) => {
  const [activeImageIdx, setActiveImageIdx] = useState(0);
  const [selectedSize, setSelectedSize] = useState<string>('');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'details' | 'fabric' | 'fit' | 'care'>('details');
  const [citySelect, setCitySelect] = useState<'chattogram' | 'nationwide'>('chattogram');
  const [copiedLink, setCopiedLink] = useState(false);
  const [addedToast, setAddedToast] = useState(false);

  useEffect(() => {
    if (product && product.sizes.length > 0) {
      setSelectedSize(product.sizes[0]);
      setActiveImageIdx(0);
      setQuantity(1);
    }
  }, [product]);

  if (!isOpen || !product) return null;

  const isBn = language === 'bn';
  const allImages = [product.image, ...product.additionalImages.filter(img => img !== product.image)];

  const handleAdd = () => {
    onAddToCart(product, selectedSize, product.color, quantity);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  const handleBuy = () => {
    onBuyNow(product, selectedSize, product.color, quantity);
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/75 backdrop-blur-md animate-fadeIn">
      <div 
        className="bg-white rounded-3xl w-full max-w-5xl max-h-[92vh] overflow-hidden shadow-2xl flex flex-col md:flex-row relative"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-full transition-colors shadow-sm"
          aria-label="Close modal"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left Column: Image Gallery */}
        <div className="w-full md:w-1/2 p-4 sm:p-6 bg-stone-50 flex flex-col justify-between border-r border-stone-200">
          <div className="relative aspect-[3/4] w-full rounded-2xl overflow-hidden bg-stone-200 shadow-inner group">
            <img
              src={allImages[activeImageIdx] || product.image}
              alt={product.title}
              className="w-full h-full object-cover object-top transition-all duration-300"
            />
            {product.isBestseller && (
              <span className="absolute top-3 left-3 bg-stone-900 text-amber-400 text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full shadow-md flex items-center space-x-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>ALIF SHOP Bestseller</span>
              </span>
            )}
          </div>

          {allImages.length > 1 && (
            <div className="flex gap-2 mt-4 overflow-x-auto pb-1">
              {allImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIdx(idx)}
                  className={`w-16 h-20 rounded-xl overflow-hidden border-2 shrink-0 transition-all ${
                    activeImageIdx === idx ? 'border-amber-600 shadow-md scale-102' : 'border-stone-300 opacity-70 hover:opacity-100'
                  }`}
                >
                  <img src={img} alt="Thumbnail" className="w-full h-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Right Column: Details & Purchase */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 overflow-y-auto flex flex-col justify-between space-y-5">
          <div>
            <div className="flex items-center justify-between text-xs text-stone-500 mb-1">
              <span className="uppercase tracking-widest font-bold text-amber-700">
                {isBn ? product.categoryNameBn : product.categoryName}
              </span>
              <span className="font-mono text-stone-400">SKU: {product.sku}</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900 leading-snug">
              {isBn ? product.titleBn : product.title}
            </h2>

            {/* Ratings & Share */}
            <div className="flex items-center justify-between mt-2 pt-1">
              <div className="flex items-center space-x-2">
                <div className="flex text-amber-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <span className="text-xs font-semibold text-stone-700">
                  {product.rating} ({product.reviewCount} {isBn ? 'রিভিউ' : 'reviews'})
                </span>
              </div>

              <button
                onClick={handleShare}
                className="text-xs text-stone-500 hover:text-stone-800 flex items-center space-x-1"
                title="Share product link"
              >
                <Share2 className="w-3.5 h-3.5" />
                <span>{copiedLink ? (isBn ? 'কপি হয়েছে!' : 'Link Copied!') : (isBn ? 'শেয়ার' : 'Share')}</span>
              </button>
            </div>

            {/* Price Box */}
            <div className="mt-4 p-4 rounded-2xl bg-stone-50 border border-stone-200 flex items-baseline justify-between">
              <div>
                <div className="text-xs text-stone-500 uppercase tracking-wider font-semibold">
                  {isBn ? 'মূল্য' : 'Price'}
                </div>
                <div className="flex items-baseline space-x-3 mt-0.5">
                  <span className="text-2xl sm:text-3xl font-extrabold font-mono text-stone-900">
                    {formatPrice(product.price, currency)}
                  </span>
                  {product.originalPrice && (
                    <span className="text-sm font-mono text-stone-400 line-through">
                      {formatPrice(product.originalPrice, currency)}
                    </span>
                  )}
                  {product.discountPercent && (
                    <span className="bg-amber-100 text-amber-800 text-xs font-bold px-2 py-0.5 rounded-full">
                      -{product.discountPercent}% OFF
                    </span>
                  )}
                </div>
              </div>

              <div className="text-right">
                <span className="inline-flex items-center text-xs font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
                  <Check className="w-3 h-3 mr-1" />
                  {isBn ? 'স্টকে বিদ্যমান' : 'In Stock'}
                </span>
              </div>
            </div>

            {/* Fabric & Color info */}
            <div className="mt-4 flex items-center justify-between text-xs">
              <div>
                <span className="text-stone-500 font-bold block">{isBn ? 'ফ্যাব্রিক / কাপড়:' : 'Fabric:'}</span>
                <span className="font-semibold text-stone-800">{isBn ? product.fabricBn : product.fabric}</span>
              </div>

              <div className="text-right">
                <span className="text-stone-500 font-bold block">{isBn ? 'রং:' : 'Color:'}</span>
                <div className="flex items-center space-x-1.5 justify-end mt-0.5">
                  <span className="w-3.5 h-3.5 rounded-full border border-stone-300" style={{ backgroundColor: product.colorCode }} />
                  <span className="font-medium text-stone-800">{product.color}</span>
                </div>
              </div>
            </div>

            {/* Size Selector */}
            <div className="mt-5">
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold uppercase tracking-wider text-stone-700">
                  {isBn ? 'সাইজ বেছে নিন:' : 'Select Size:'}
                </label>
                <button
                  type="button"
                  onClick={() => onOpenSizeChart(product.categoryGroup)}
                  className="text-xs text-amber-700 hover:underline font-bold flex items-center space-x-1"
                >
                  <Ruler className="w-3.5 h-3.5" />
                  <span>{isBn ? 'সাইজ চার্ট দেখুন' : 'View Size Chart'}</span>
                </button>
              </div>

              <div className="flex flex-wrap gap-2">
                {product.sizes.map((sz) => (
                  <button
                    key={sz}
                    onClick={() => setSelectedSize(sz)}
                    className={`py-2 px-3.5 rounded-xl text-xs font-bold transition-all border ${
                      selectedSize === sz
                        ? 'bg-amber-600 text-white border-amber-600 shadow-md'
                        : 'bg-white text-stone-800 border-stone-200 hover:border-stone-400'
                    }`}
                  >
                    {sz}
                  </button>
                ))}
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="mt-5 flex items-center space-x-4">
              <span className="text-xs font-bold uppercase tracking-wider text-stone-700">
                {isBn ? 'পরিমাণ:' : 'Quantity:'}
              </span>
              <div className="flex items-center border border-stone-300 rounded-xl bg-white overflow-hidden">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="p-2 text-stone-600 hover:bg-stone-100 transition-colors"
                  disabled={quantity <= 1}
                >
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="px-4 text-sm font-bold font-mono text-stone-900">{quantity}</span>
                <button
                  onClick={() => setQuantity(quantity + 1)}
                  className="p-2 text-stone-600 hover:bg-stone-100 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Action Buttons: Add to Bag + Buy Now + Wishlist */}
            <div className="mt-6 flex gap-3">
              <button
                onClick={handleAdd}
                className="flex-1 py-3.5 bg-stone-900 hover:bg-stone-800 text-white rounded-2xl text-xs sm:text-sm font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center space-x-2 cursor-pointer"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{addedToast ? (isBn ? 'ব্যাগে যোগ হয়েছে!' : 'Added!') : (isBn ? 'ব্যাগে যোগ করুন' : 'Add to Bag')}</span>
              </button>

              <button
                onClick={handleBuy}
                className="flex-1 py-3.5 bg-amber-600 hover:bg-amber-700 text-white rounded-2xl text-xs sm:text-sm font-bold uppercase tracking-wider transition-all shadow-md flex items-center justify-center space-x-2 cursor-pointer"
              >
                <span>{isBn ? 'এখনই অর্ডার করুন' : 'Order Now'}</span>
              </button>

              <button
                onClick={() => onToggleWishlist(product)}
                className={`p-3.5 rounded-2xl border transition-all ${
                  isWishlisted
                    ? 'bg-amber-50 text-amber-700 border-amber-600'
                    : 'border-stone-300 text-stone-700 hover:border-stone-500'
                }`}
                aria-label="Wishlist"
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-amber-600' : ''}`} />
              </button>
            </div>

            {/* Delivery Estimator for Chattogram & Nationwide */}
            <div className="mt-6 p-4 rounded-2xl bg-amber-50/70 border border-amber-200 space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-1.5 font-bold text-stone-900">
                  <Truck className="w-4 h-4 text-amber-700" />
                  <span>{isBn ? 'ডেলিভারি এলাকা ও খরচ' : 'Delivery Charges'}</span>
                </div>
                <div className="flex space-x-1 text-[11px]">
                  <button
                    onClick={() => setCitySelect('chattogram')}
                    className={`px-2.5 py-0.5 rounded font-semibold transition-all ${
                      citySelect === 'chattogram' ? 'bg-amber-700 text-white' : 'text-stone-600 bg-white'
                    }`}
                  >
                    রাউজান / চট্টগ্রাম
                  </button>
                  <button
                    onClick={() => setCitySelect('nationwide')}
                    className={`px-2.5 py-0.5 rounded font-semibold transition-all ${
                      citySelect === 'nationwide' ? 'bg-amber-700 text-white' : 'text-stone-600 bg-white'
                    }`}
                  >
                    সারা দেশ
                  </button>
                </div>
              </div>

              <p className="text-stone-700 leading-relaxed text-[11px]">
                {citySelect === 'chattogram' ? (
                  isBn 
                    ? 'রাউজান ও চট্টগ্রাম জেলার ভেতরে: ২৪-৪৮ ঘণ্টায় হোম ডেলিভারি (৳৬০)। ২,০০০ টাকার অর্ডারে সম্পূর্ণ ফ্রি ডেলিভারি!' 
                    : 'Inside Raozan & Chattogram: 24–48 Hours Doorstep Delivery (৳60). Free over ৳2,000.'
                ) : (
                  isBn 
                    ? 'চট্টগ্রামের বাইরে (ঢাকা, সিলেট সহ সারা দেশে): ২-৩ কার্যদিবস (৳১২০)। ক্যাশ অন ডেলিভারি সুবিধা প্রযোজ্য।' 
                    : 'Outside Chattogram (Nationwide): 2–3 Business Days (৳120). Cash on delivery available.'
                )}
              </p>
            </div>

            {/* Tabs */}
            <div className="mt-5 pt-3 border-t border-stone-200">
              <div className="flex border-b border-stone-200 text-xs font-bold uppercase tracking-wider text-stone-500 overflow-x-auto">
                <button
                  onClick={() => setActiveTab('details')}
                  className={`pb-2 px-3 border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === 'details' ? 'border-amber-700 text-amber-700' : 'border-transparent hover:text-stone-800'
                  }`}
                >
                  {isBn ? 'বিবরণ' : 'Description'}
                </button>
                <button
                  onClick={() => setActiveTab('fit')}
                  className={`pb-2 px-3 border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === 'fit' ? 'border-amber-700 text-amber-700' : 'border-transparent hover:text-stone-800'
                  }`}
                >
                  {isBn ? 'ফিটিং ও মেটেরিয়াল' : 'Fit & Material'}
                </button>
                <button
                  onClick={() => setActiveTab('care')}
                  className={`pb-2 px-3 border-b-2 transition-colors whitespace-nowrap ${
                    activeTab === 'care' ? 'border-amber-700 text-amber-700' : 'border-transparent hover:text-stone-800'
                  }`}
                >
                  {isBn ? 'পরিচর্যা' : 'Wash Care'}
                </button>
              </div>

              <div className="py-3 text-xs text-stone-600 leading-relaxed">
                {activeTab === 'details' && (
                  <p>{isBn ? product.descriptionBn : product.description}</p>
                )}
                {activeTab === 'fit' && (
                  <div className="space-y-1">
                    <p><strong className="text-stone-900">ফিটিং:</strong> {product.details.fit}</p>
                    <p><strong className="text-stone-900">উপাদান:</strong> {product.details.material}</p>
                    <p><strong className="text-stone-900">বৈশিষ্ট্য:</strong> {product.details.features}</p>
                  </div>
                )}
                {activeTab === 'care' && (
                  <p>{product.details.care}</p>
                )}
              </div>
            </div>

            {/* Trust Badges */}
            <div className="pt-3 border-t border-stone-100 grid grid-cols-2 gap-3 text-[11px] text-stone-600">
              <div className="flex items-center space-x-2">
                <RotateCcw className="w-4 h-4 text-amber-700" />
                <span>{isBn ? '৭ দিনে সহজ পণ্য পরিবর্তন' : '7-Day Easy Exchange'}</span>
              </div>
              <div className="flex items-center space-x-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>{isBn ? 'গহিরা, রাউজান • ১০০% বিশ্বস্ত' : '100% Quality Guaranteed'}</span>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
};

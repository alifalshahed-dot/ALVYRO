import React, { useState, useMemo } from 'react';
import { SlidersHorizontal, Sparkles, RotateCcw, X, Filter } from 'lucide-react';
import { Product, Currency, Language, ProductCategory } from '../types';
import { ProductCard } from './ProductCard';
import { CATEGORIES } from '../data/products';

interface ProductGridProps {
  products: Product[];
  currency: Currency;
  language: Language;
  wishlistIds: string[];
  onToggleWishlist: (p: Product) => void;
  onQuickView: (p: Product) => void;
  onAddToCart: (p: Product, size: string, color: string) => void;
  activeCategory: ProductCategory;
  setActiveCategory: (c: ProductCategory) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
}

export const ProductGrid: React.FC<ProductGridProps> = ({
  products,
  currency,
  language,
  wishlistIds,
  onToggleWishlist,
  onQuickView,
  onAddToCart,
  activeCategory,
  setActiveCategory,
  searchQuery,
  setSearchQuery
}) => {
  const [activeGroup, setActiveGroup] = useState<'all' | 't-shirts-polo' | 'shirts' | 'pants'>('all');
  const [selectedSize, setSelectedSize] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [showFiltersPanel, setShowFiltersPanel] = useState(false);
  const [onlySale, setOnlySale] = useState(false);

  const isBn = language === 'bn';

  const sizes = ['all', 'M', 'L', 'XL', 'XXL', '28', '30', '32', '34', '36'];

  const filteredProducts = useMemo(() => {
    return products.filter((p) => {
      // Group filter
      if (activeGroup !== 'all' && p.categoryGroup !== activeGroup) {
        return false;
      }

      // Specific Category filter
      if (activeCategory !== 'all' && p.category !== activeCategory) {
        return false;
      }

      // Size filter
      if (selectedSize !== 'all' && !p.sizes.includes(selectedSize) && !p.sizes.some(s => s.includes(selectedSize))) {
        return false;
      }

      // Sale filter
      if (onlySale && !p.discountPercent) return false;

      // Search query
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesTitle = p.title.toLowerCase().includes(q) || p.titleBn.includes(q);
        const matchesSku = p.sku.toLowerCase().includes(q);
        const matchesFabric = p.fabric.toLowerCase().includes(q);
        const matchesCategory = p.categoryName.toLowerCase().includes(q) || p.categoryNameBn.includes(q);
        if (!matchesTitle && !matchesSku && !matchesFabric && !matchesCategory) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return (b.featured ? 1 : 0) - (a.featured ? 1 : 0);
    });
  }, [products, activeGroup, activeCategory, selectedSize, onlySale, searchQuery, sortBy]);

  const hasActiveFilters = activeGroup !== 'all' || activeCategory !== 'all' || selectedSize !== 'all' || onlySale || searchQuery !== '';

  const handleResetFilters = () => {
    setActiveGroup('all');
    setActiveCategory('all');
    setSelectedSize('all');
    setOnlySale(false);
    setSearchQuery('');
  };

  return (
    <section id="catalog-section" className="py-12 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
      
      {/* Title & Group Tabs */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-6 border-b border-stone-200">
        <div>
          <div className="flex items-center space-x-2 text-amber-700 text-xs font-bold uppercase tracking-[0.2em] mb-1">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isBn ? 'আলিফ শপ ক্যাটালগ' : 'ALIF SHOP READYWEAR'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-stone-900 tracking-tight">
            {activeGroup === 't-shirts-polo' 
              ? (isBn ? 'টি-শার্ট ও পোলো টি-শার্ট' : 'T-Shirts & Polo Shirts') 
              : activeGroup === 'shirts' 
              ? (isBn ? 'ক্যাজুয়াল ও ফরমাল শার্ট' : 'Casual & Formal Shirts') 
              : activeGroup === 'pants'
              ? (isBn ? 'কোরিয়ান প্যান্ট ও ট্রাউজার্স' : 'Pants Collection')
              : (isBn ? 'সকল পোশাক সংগ্রহ' : 'All Collections')}
          </h2>
          <p className="text-stone-500 text-xs sm:text-sm mt-1">
            {isBn 
              ? `মোট ${filteredProducts.length}টি প্রিমিয়াম পোশাক প্রদর্শিত হচ্ছে` 
              : `Displaying ${filteredProducts.length} menswear pieces ready to dispatch from Raozan`}
          </p>
        </div>

        {/* Group Selector Tabs */}
        <div className="flex items-center bg-stone-100 p-1.5 rounded-2xl border border-stone-200 overflow-x-auto self-start md:self-auto">
          {[
            { id: 'all', label: isBn ? 'সকল' : 'All' },
            { id: 't-shirts-polo', label: isBn ? 'টি-শার্ট ও পোলো' : 'T-Shirts & Polo' },
            { id: 'shirts', label: isBn ? 'শার্ট কালেকশন' : 'Shirts' },
            { id: 'pants', label: isBn ? 'প্যান্ট কালেকশন' : 'Pants' }
          ].map((grp) => (
            <button
              key={grp.id}
              onClick={() => {
                setActiveGroup(grp.id as any);
                setActiveCategory('all');
              }}
              className={`px-4 sm:px-5 py-2 rounded-xl text-xs font-bold uppercase tracking-wider transition-all whitespace-nowrap cursor-pointer ${
                activeGroup === grp.id
                  ? 'bg-amber-600 text-white shadow-sm font-extrabold'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              {grp.label}
            </button>
          ))}
        </div>
      </div>

      {/* Subcategory Filter Chips */}
      <div className="py-4 overflow-x-auto flex items-center space-x-2 scrollbar-none">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => {
              setActiveCategory(cat.id as ProductCategory);
              // sync group if clicking specific category
              if (cat.id === 't-shirt' || cat.id === 'polo-shirt') setActiveGroup('t-shirts-polo');
              else if (cat.id === 'casual-shirt' || cat.id === 'formal-shirt') setActiveGroup('shirts');
              else if (cat.id === 'korean-pant' || cat.id === 'formal-pant' || cat.id === 'casual-trouser') setActiveGroup('pants');
              else setActiveGroup('all');
            }}
            className={`px-4 py-2 rounded-full text-xs font-bold whitespace-nowrap transition-all border cursor-pointer ${
              activeCategory === cat.id
                ? 'bg-stone-900 text-white border-stone-900 shadow-sm'
                : 'bg-white text-stone-700 border-stone-200 hover:border-stone-400'
            }`}
          >
            {isBn ? cat.nameBn : cat.name}
          </button>
        ))}
      </div>

      {/* Toolbar */}
      <div className="mt-2 flex items-center justify-between flex-wrap gap-4 bg-stone-50 p-4 rounded-2xl border border-stone-200 text-xs">
        <div className="flex items-center space-x-3 flex-wrap gap-2">
          <button
            onClick={() => setShowFiltersPanel(!showFiltersPanel)}
            className={`px-4 py-2 rounded-xl font-bold uppercase tracking-wider flex items-center space-x-2 transition-all border ${
              showFiltersPanel
                ? 'bg-stone-900 text-white border-stone-900'
                : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>{isBn ? 'সাইজ ফিল্টার' : 'Size Filter'}</span>
            {hasActiveFilters && <span className="w-2 h-2 rounded-full bg-amber-500" />}
          </button>

          <button
            onClick={() => setOnlySale(!onlySale)}
            className={`px-3 py-2 rounded-xl font-semibold transition-all border ${
              onlySale
                ? 'bg-amber-500 text-stone-900 border-amber-600 font-bold'
                : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-100'
            }`}
          >
            🔥 {isBn ? 'ডিসকাউন্ট অফার' : 'Sale Offers'}
          </button>

          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="text-stone-500 hover:text-amber-700 flex items-center space-x-1 py-1 px-2 font-medium"
            >
              <RotateCcw className="w-3 h-3" />
              <span>{isBn ? 'ফিল্টার রিসেট' : 'Reset All'}</span>
            </button>
          )}
        </div>

        {/* Sorting Dropdown */}
        <div className="flex items-center space-x-2">
          <span className="text-stone-500 font-medium">{isBn ? 'সাজান:' : 'Sort By:'}</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-white border border-stone-200 rounded-xl px-3 py-2 text-stone-800 font-semibold focus:outline-none focus:ring-1 focus:ring-amber-600"
          >
            <option value="featured">{isBn ? 'জনপ্রিয়তা (ফিচার্ড)' : 'Featured & New'}</option>
            <option value="price-asc">{isBn ? 'দাম: কম থেকে বেশি' : 'Price: Low to High'}</option>
            <option value="price-desc">{isBn ? 'দাম: বেশি থেকে কম' : 'Price: High to Low'}</option>
            <option value="rating">{isBn ? 'গ্রাহক রেটিং অনুযায়ী' : 'Customer Rating'}</option>
          </select>
        </div>
      </div>

      {/* Expanded Size Filter */}
      {showFiltersPanel && (
        <div className="mt-3 p-5 bg-white border border-stone-200 rounded-2xl shadow-sm space-y-3 animate-fadeIn">
          <label className="block text-xs font-bold uppercase tracking-wider text-stone-700">
            {isBn ? 'সাইজ বেছে নিন (টি-শার্ট / শার্ট / প্যান্ট):' : 'Select Size (Tees / Shirts / Pants):'}
          </label>
          <div className="flex flex-wrap gap-2">
            {sizes.map((sz) => (
              <button
                key={sz}
                onClick={() => setSelectedSize(sz)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  selectedSize === sz
                    ? 'bg-amber-600 text-white'
                    : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                }`}
              >
                {sz === 'all' ? (isBn ? 'সকল সাইজ' : 'All Sizes') : sz}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-20 bg-white rounded-3xl border border-stone-200 mt-8">
          <div className="w-16 h-16 rounded-full bg-stone-100 mx-auto flex items-center justify-center text-stone-400 mb-4">
            <Filter className="w-8 h-8" />
          </div>
          <h3 className="text-xl font-serif font-bold text-stone-800">
            {isBn ? 'কোন পোশাকের সন্ধান পাওয়া যায়নি' : 'No matching items found'}
          </h3>
          <p className="text-stone-500 text-sm mt-1 max-w-md mx-auto">
            {isBn 
              ? 'অনুগ্রহ করে অন্য কোনো সাইজ বা ক্যাটাগরি বেছে নিন।' 
              : 'Try clearing your filter or selecting another category.'}
          </p>
          <button
            onClick={handleResetFilters}
            className="mt-6 px-6 py-2.5 bg-amber-600 text-white rounded-full text-xs uppercase font-bold tracking-wider hover:bg-amber-700 transition-all"
          >
            {isBn ? 'সব ফিল্টার মুছুন' : 'Reset Filters'}
          </button>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
          {filteredProducts.map((product) => (
            <ProductCard
              key={product.id}
              product={product}
              currency={currency}
              language={language}
              isWishlisted={wishlistIds.includes(product.id)}
              onToggleWishlist={onToggleWishlist}
              onQuickView={onQuickView}
              onAddToCart={onAddToCart}
            />
          ))}
        </div>
      )}

    </section>
  );
};

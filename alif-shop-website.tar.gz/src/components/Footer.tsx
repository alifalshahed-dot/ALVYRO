import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ArrowRight, 
  ShieldCheck, 
  Truck, 
  RotateCcw, 
  Sparkles,
  CheckCircle2,
  PhoneCall,
  MessageCircle
} from 'lucide-react';
import { Language, ProductCategory } from '../types';
import { STORE_INFO } from '../data/storeInfo';

interface FooterProps {
  language: Language;
  onOpenAbout: () => void;
  onOpenContact: () => void;
  onOpenReturnPolicy: () => void;
  onOpenDeliveryPolicy: () => void;
  onOpenOrderTracking: () => void;
  onOpenSizeChart: () => void;
  onNavigateCategory: (category: ProductCategory) => void;
}

export const Footer: React.FC<FooterProps> = ({
  language,
  onOpenAbout,
  onOpenContact,
  onOpenReturnPolicy,
  onOpenDeliveryPolicy,
  onOpenOrderTracking,
  onOpenSizeChart,
  onNavigateCategory
}) => {
  const [emailSub, setEmailSub] = useState('');
  const [subSuccess, setSubSuccess] = useState(false);

  const isBn = language === 'bn';

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (emailSub.trim()) {
      setSubSuccess(true);
      setTimeout(() => {
        setEmailSub('');
        setSubSuccess(false);
      }, 3500);
    }
  };

  return (
    <footer className="bg-stone-950 text-stone-300 text-xs border-t border-stone-800">
      
      {/* Top Privilege / Hotline strip */}
      <div className="border-b border-stone-800 py-10 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-6">
          <div className="max-w-xl text-center lg:text-left">
            <span className="text-amber-500 font-bold uppercase tracking-widest text-[11px] flex items-center justify-center lg:justify-start space-x-1.5 mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{isBn ? 'আলিফ শপ বিশেষ অফার' : 'ALIF SHOP PRIVILEGE'}</span>
            </span>
            <h3 className="text-2xl font-serif font-bold text-white tracking-tight">
              {isBn 
                ? 'প্রথম অর্ডারে ১০% ছাড় পেতে কোড ব্যবহার করুন: ALIF10' 
                : 'Get 10% Off On Your First Order With Code: ALIF10'}
            </h3>
            <p className="text-stone-400 mt-1 text-xs">
              {isBn 
                ? `${STORE_INFO.addressBn} • সারা দেশে ক্যাশ অন ডেলিভারি` 
                : `${STORE_INFO.address} • Doorstep Cash on Delivery`}
            </p>
          </div>

          <div className="w-full max-w-md">
            {subSuccess ? (
              <div className="p-3.5 rounded-xl bg-emerald-900/60 border border-emerald-500 text-emerald-200 flex items-center space-x-2 text-xs font-semibold">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>{isBn ? 'ধন্যবাদ! ভাউচার কোড ALIF10 সক্রিয় হয়েছে।' : 'Thank you! Voucher ALIF10 is activated.'}</span>
              </div>
            ) : (
              <form onSubmit={handleSubscribe} className="flex gap-2">
                <input
                  type="email"
                  required
                  value={emailSub}
                  onChange={(e) => setEmailSub(e.target.value)}
                  placeholder={isBn ? 'আপনার ইমেইল অ্যাড্রেস...' : 'Enter your email...'}
                  className="flex-1 px-4 py-3 bg-stone-900 border border-stone-700 rounded-xl text-white placeholder-stone-500 focus:outline-none focus:border-amber-600 text-xs"
                />
                <button
                  type="submit"
                  className="px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold uppercase tracking-wider transition-colors shrink-0 flex items-center space-x-1.5"
                >
                  <span>{isBn ? 'সাবস্ক্রাইব' : 'Subscribe'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          
          {/* Brand Info */}
          <div className="space-y-4">
            <div>
              <span className="font-serif tracking-[0.16em] text-2xl sm:text-3xl font-extrabold text-white block">
                ALIF SHOP
              </span>
              <span className="text-[10px] uppercase tracking-[0.22em] text-amber-500 font-bold block mt-0.5">
                {STORE_INFO.tagline}
              </span>
            </div>

            <p className="text-stone-400 text-xs leading-relaxed font-light">
              {isBn 
                ? 'চট্টগ্রামের রাউজান উপজেলার গহিরায় অবস্থিত শীর্ষস্থানীয় পোশাকের শপ। কম্বড কটন টি-শার্ট, প্রিমিয়াম পোলো, ট্রেন্ডি কোরিয়ান প্যান্ট ও ফরমাল শার্টের বিশ্বস্ত প্রতিষ্ঠান।' 
                : 'A modern menswear boutique based in Gohira, Raozan, Chattogram offering comfortable combed cotton tees, tailored shirts, and trending Korean pleated trousers.'}
            </p>

            <div className="space-y-1.5 text-stone-300 text-xs">
              <div className="flex items-start space-x-2">
                <MapPin className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                <span>{STORE_INFO.addressBn}</span>
              </div>
              <div className="flex items-center space-x-2 font-mono">
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <a href={`tel:${STORE_INFO.phone}`} className="hover:text-amber-400 font-bold">
                  {STORE_INFO.phoneDisplay}
                </a>
              </div>
              <div className="flex items-center space-x-2 text-[11px] text-stone-400">
                <Clock className="w-3.5 h-3.5 shrink-0" />
                <span>{STORE_INFO.hoursBn}</span>
              </div>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-white font-serif font-bold text-sm uppercase tracking-wider mb-4">
              {isBn ? 'পোশাকের ক্যাটাগরি' : 'Clothing Categories'}
            </h4>
            <ul className="space-y-2.5 text-stone-400">
              <li>
                <button onClick={() => onNavigateCategory('t-shirt')} className="hover:text-white transition-colors">
                  {isBn ? 'ক্যাজুয়াল টি-শার্ট (১৮০ জিএসএম)' : 'Casual T-Shirts'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateCategory('polo-shirt')} className="hover:text-white transition-colors">
                  {isBn ? 'প্রিমিয়াম পোলো টি-শার্ট (ম্যাটি পিকে)' : 'Premium Polo Shirts'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateCategory('casual-shirt')} className="hover:text-white transition-colors">
                  {isBn ? 'ক্যাজুয়াল শার্ট (লিনেন ও কিউবান)' : 'Casual Shirts'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateCategory('formal-shirt')} className="hover:text-white transition-colors">
                  {isBn ? 'ফরমাল শার্ট (অক্সফোর্ড কটন)' : 'Formal Office Shirts'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateCategory('korean-pant')} className="hover:text-white transition-colors">
                  {isBn ? 'কোরিয়ান প্যান্ট (প্লিটেড ব্যাগি)' : 'Korean Pleated Pants'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateCategory('formal-pant')} className="hover:text-white transition-colors">
                  {isBn ? 'ফরমাল প্যান্ট (৪-ওয়ে স্ট্রেচ)' : 'Formal Gabardine Pants'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateCategory('casual-trouser')} className="hover:text-white transition-colors">
                  {isBn ? 'ক্যাজুয়াল ট্রাউজার্স ও চিনো' : 'Casual Trousers & Chinos'}
                </button>
              </li>
            </ul>
          </div>

          {/* Information & Policies */}
          <div>
            <h4 className="text-white font-serif font-bold text-sm uppercase tracking-wider mb-4">
              {isBn ? 'তথ্য ও পলিসি' : 'Information & Policies'}
            </h4>
            <ul className="space-y-2.5 text-stone-400">
              <li>
                <button onClick={onOpenAbout} className="hover:text-white transition-colors">
                  {isBn ? 'এবাউট আস (আলিফ শপ)' : 'About Us'}
                </button>
              </li>
              <li>
                <button onClick={onOpenContact} className="hover:text-white transition-colors">
                  {isBn ? 'কন্টাক্ট আস ও হটলাইন' : 'Contact Us & Hotline'}
                </button>
              </li>
              <li>
                <button onClick={onOpenReturnPolicy} className="hover:text-white transition-colors">
                  {isBn ? 'রিটার্ন ও এক্সচেঞ্জ পলিসি (৭ দিন)' : 'Return & Exchange Policy'}
                </button>
              </li>
              <li>
                <button onClick={onOpenDeliveryPolicy} className="hover:text-white transition-colors">
                  {isBn ? 'ডেলিভারি পলিসি (ক্যাশ অন ডেলিভারি)' : 'Delivery Policy'}
                </button>
              </li>
              <li>
                <button onClick={onOpenOrderTracking} className="hover:text-white transition-colors">
                  {isBn ? 'লাইভ অর্ডার ট্র্যাকিং' : 'Track Your Order'}
                </button>
              </li>
              <li>
                <button onClick={onOpenSizeChart} className="hover:text-white transition-colors">
                  {isBn ? 'সাইজ ও মেজারমেন্ট গাইড' : 'Size Chart'}
                </button>
              </li>
            </ul>
          </div>

          {/* Quick Help & Location Box */}
          <div className="space-y-4">
            <h4 className="text-white font-serif font-bold text-sm uppercase tracking-wider">
              {isBn ? 'গ্রাহক সহায়তা ও অর্ডার' : 'Customer Assistance'}
            </h4>
            
            <div className="p-4 rounded-2xl bg-stone-900 border border-stone-800 space-y-2 text-stone-300">
              <span className="text-amber-500 font-bold block text-xs">📞 ফোন অর্ডার ও হেল্পলাইন:</span>
              <a href={`tel:${STORE_INFO.phone}`} className="text-base font-mono font-bold text-white block">
                {STORE_INFO.phoneDisplay}
              </a>
              <p className="text-[11px] text-stone-400">
                যেকোনো সাইজ বা অর্ডারের সহায়তায় সরাসরি ফোন দিন।
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-emerald-950/40 border border-emerald-800/60 space-y-2">
              <span className="text-emerald-400 font-bold block text-xs">💬 হোয়াটসঅ্যাপ অর্ডার:</span>
              <a 
                href={`https://wa.me/${STORE_INFO.whatsapp}?text=Hello%20ALIF%20SHOP,%20I%20want%20to%20order.`} 
                target="_blank" 
                rel="noreferrer"
                className="inline-flex items-center space-x-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>{isBn ? 'হোয়াটসঅ্যাপে চ্যাট' : 'Chat on WhatsApp'}</span>
              </a>
            </div>
          </div>

        </div>

        {/* Bottom strip */}
        <div className="mt-12 pt-8 border-t border-stone-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-stone-400">
          <div className="flex items-center space-x-2 flex-wrap">
            <span>পেমেন্ট পার্টনার:</span>
            <span className="px-2 py-0.5 rounded bg-stone-900 text-white font-bold">ক্যাশ অন ডেলিভারি (COD)</span>
            <span className="px-2 py-0.5 rounded bg-pink-900/60 text-pink-300 font-bold">bKash</span>
            <span className="px-2 py-0.5 rounded bg-orange-900/60 text-orange-300 font-bold">Nagad</span>
            <span className="px-2 py-0.5 rounded bg-blue-900/60 text-blue-300 font-bold">Visa / Master</span>
          </div>

          <p className="text-stone-500">
            © 2026 ALIF SHOP (আলিফ শপ), গহিরা, রাউজান, চট্টগ্রাম। সর্বস্বত্ব সংরক্ষিত।
          </p>
        </div>
      </div>

    </footer>
  );
};
